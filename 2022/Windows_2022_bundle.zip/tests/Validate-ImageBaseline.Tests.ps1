# Requires: Pester 5.x
BeforeAll {
  Set-StrictMode -Version Latest
  $ErrorActionPreference = 'Stop'
}

Describe "Image Baseline Validation" {

  It "Has TLS 1.2 enabled for Server and Client" {
    $s = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -ErrorAction Stop).Enabled
    $c = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -ErrorAction Stop).Enabled
    $s | Should -Be 1
    $c | Should -Be 1
  }

  It "Has SQL media staged" {
    (Get-ChildItem -Path 'C:\Stage' -Filter 'sql2022-*.iso' -ErrorAction SilentlyContinue).Count | Should -BeGreaterThan 0
  }

  It "Has CU package staged" {
    Test-Path 'C:\Stage\sql2022-cu.exe' | Should -BeTrue
  }

  It "Has agent installers staged but not enrolled" {
    Test-Path 'C:\Stage\TaniumSetupClient.exe' | Should -BeTrue
    (Get-Service -Name 'TaniumClient' -ErrorAction SilentlyContinue) | Should -Be $null
    Test-Path 'C:\Stage\CrowdStrikeSensor.exe' | Should -BeTrue
    (Get-Service -Name 'CSFalconService' -ErrorAction SilentlyContinue) | Should -Be $null
  }

  It "Has LGPO imported if provided" {
    # Not strictly required, but if LGPO.exe staged, we expect the import to have run
    # You can extend this by checking a known policy key/value from your baseline
    $exists = Test-Path 'C:\Stage\lgpo\LGPO.exe'
    $exists | Should -BeTrue
  }
}
