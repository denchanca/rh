# PowerShell script to set up F: drive and configure SQL Server 2022 default paths and TempDB
# Requires administrative privileges and sysadmin role in SQL Server

# Configuration variables
$SqlInstanceName = "MSSQLSERVER"
$ServiceAccount = "NT AUTHORITY\System"
$SqlServer = "."
$LogFile = "C:\Temp\ConfigureSqlFDrive_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Directories to create on F: drive
$Directories = @(
    "F:\MP_DB1\MSSQL16.MSSQLSERVER\MSSQL\Data\Encrypted",
    "F:\MP_LOG1\MSSQL16.MSSQLSERVER\MSSQL\Log\Encrypted",
    "F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Data",
    "F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Log"
)

# T-SQL script content to move TempDB files
$TSqlScript = @"
-- Enable xp_cmdshell if not already enabled (needed for service restart)
BEGIN TRY
    EXEC sp_configure 'show advanced options', 1;
    RECONFIGURE WITH OVERRIDE;
    EXEC sp_configure 'xp_cmdshell', 1;
    RECONFIGURE WITH OVERRIDE;
    PRINT 'xp_cmdshell enabled successfully.';
END TRY
BEGIN CATCH
    PRINT 'Error enabling xp_cmdshell: ' + ERROR_MESSAGE() + ' Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR);
    THROW;
END CATCH;

-- Step 1: Move existing TempDB files to new location on F: drive
BEGIN TRY
    ALTER DATABASE tempdb 
    MODIFY FILE (
        NAME = N'tempdev',
        FILENAME = N'F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Data\tempdb.mdf',
        SIZE = 8MB,
        FILEGROWTH = 1MB
    );
    PRINT 'Modified TempDB primary data file to F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Data\tempdb.mdf';
END TRY
BEGIN CATCH
    PRINT 'Error modifying tempdev: ' + ERROR_MESSAGE() + ' Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR);
    THROW;
END CATCH;

BEGIN TRY
    ALTER DATABASE tempdb 
    MODIFY FILE (
        NAME = N'templog',
        FILENAME = N'F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Log\templog.ldf',
        SIZE = 8MB,
        FILEGROWTH = 1MB
    );
    PRINT 'Modified TempDB log file to F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Log\templog.ldf';
END TRY
BEGIN CATCH
    PRINT 'Error modifying templog: ' + ERROR_MESSAGE() + ' Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR);
    THROW;
END CATCH;

-- Step 2: Ensure TempDB has 8 data files with names tempdb_mssql_2 to tempdb_mssql_8
BEGIN TRY
    DECLARE @DataFileCount INT;
    SELECT @DataFileCount = COUNT(*) 
    FROM sys.master_files 
    WHERE database_id = DB_ID('tempdb') AND type_desc = 'ROWS';

    DECLARE @i INT = 1;
    WHILE @i < @DataFileCount
    BEGIN
        DECLARE @FileName NVARCHAR(128) = N'temp' + CAST((@i + 1) AS NVARCHAR(10));
        DECLARE @FilePath NVARCHAR(260) = N'F:\MP_TMPDB\MSSQL16.MSSQLSERVER\MSSQL\Data\tempdb_mssql_' + CAST((@i + 1) AS NVARCHAR(10)) + N'.ndf';
        PRINT 'Adding TempDB file: ' + @FileName + ' at ' + @FilePath;
        EXEC (N'
        ALTER DATABASE tempdb 
        MODIFY FILE (
            NAME = N''' + @FileName + N''',
            FILENAME = N''' + @FilePath + N''',
            SIZE = 8MB,
            FILEGROWTH = 1MB
        );');
        SET @i = @i + 1;
    END;
    PRINT 'Ensured 8 TempDB data files.';
END TRY
BEGIN CATCH
    PRINT 'Error moving TempDB files: ' + ERROR_MESSAGE() + ' Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR);
    THROW;
END CATCH;

-- Step 3: Restart SQL Server service to apply changes and recreate TempDB
BEGIN TRY
    EXEC xp_cmdshell 'NET STOP MSSQLSERVER';
    EXEC xp_cmdshell 'NET START MSSQLSERVER';
    PRINT 'SQL Server service restarted successfully.';
END TRY
BEGIN CATCH
    PRINT 'Error restarting SQL Server: ' + ERROR_MESSAGE() + ' Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR);
    THROW;
END CATCH;
"@

# Function to log messages
function Write-Log {
    param($Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$Timestamp - $Message" | Out-File -FilePath $LogFile -Append
}

# Ensure running as administrator
Write-Log "Checking for administrative privileges..."
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "Error: Script must be run as Administrator."
    Write-Error "This script requires administrative privileges. Please run PowerShell as Administrator."
    exit 1
}
Write-Log "Administrative privileges confirmed."

# Create and Verify F: drive exists
Write-Log "Creating F: drive..."
$rawDisks = Get-Disk | Where-Object { $_.PartitionStyle -eq 'RAW' } | Sort-Object Number
$disk1 = $rawDisks[0]
Initialize-Disk -Number $disk1.Number -PartitionStyle GPT -Confirm:$false
$partitionF = New-Partition -DiskNumber $disk1.Number -DriveLetter 'F' -UseMaximumSize
Format-Volume -DriveLetter 'F' -FileSystem NTFS -NewFileSystemLabel 'DataF' -Confirm:$false
Write-Log 'F: drive partitioned and formatted.'

Write-Log "Checking if F: drive exists..."
if (-not (Test-Path "F:\")) {
    Write-Log "Error: F: drive not found. Please ensure the drive is available."
    Write-Error "F: drive not found. Script cannot continue."
    exit 1
}
Write-Log "F: drive found."

# Create directories
Write-Log "Creating directories on F: drive..."
foreach ($Dir in $Directories) {
    try {
        New-Item -ItemType Directory -Path $Dir -Force -ErrorAction Stop | Out-Null
        Write-Log "Created directory: $Dir"
    }
    catch {
        Write-Log "Error creating directory $Dir $_"
        Write-Error "Failed to create directory $Dir $_"
        exit 1
    }
}

# Assign permissions to SQL Server service account
Write-Log "Assigning Full Control permissions to $ServiceAccount..."
foreach ($Dir in $Directories) {
    try {
        $Acl = Get-Acl -Path $Dir -ErrorAction Stop
        $Rule = New-Object System.Security.AccessControl.FileSystemAccessRule($ServiceAccount, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
        $Acl.AddAccessRule($Rule)
        Set-Acl -Path $Dir -AclObject $Acl -ErrorAction Stop
        Write-Log "Granted Full Control to $ServiceAccount on $Dir"
    }
    catch {
        Write-Log "Error setting permissions on $Dir $_"
        Write-Error "Failed to set permissions on $Dir $_"
        exit 1
    }
}

# Update registry settings using PowerShell
Write-Log "Updating SQL Server registry settings for default paths..."
try {
    $RegPath = "HKLM:\Software\Microsoft\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQLServer"
    Set-ItemProperty -Path $RegPath -Name "DefaultData" -Value "F:\MP_DB1\MSSQL16.MSSQLSERVER\MSSQL\Data\Encrypted" -ErrorAction Stop
    Set-ItemProperty -Path $RegPath -Name "DefaultLog" -Value "F:\MP_LOG1\MSSQL16.MSSQLSERVER\MSSQL\Log\Encrypted" -ErrorAction Stop
    Write-Log "Updated DefaultData to F:\MP_DB1\MSSQL16.MSSQLSERVER\MSSQL\Data\Encrypted"
    Write-Log "Updated DefaultLog to F:\MP_LOG1\MSSQL16.MSSQLSERVER\MSSQL\Log\Encrypted"
}
catch {
    Write-Log "Error updating registry settings: $_"
    Write-Error "Failed to update registry settings: $_"
    exit 1
}

# Execute T-SQL script to move TempDB files and configure 8 data files
Write-Log "Executing T-SQL script on SQL Server instance $SqlServer..."
try {
    $SqlOutput = Invoke-Sqlcmd -ServerInstance $SqlServer -Query $TSqlScript -ErrorAction Stop -OutputAs DataRows
    foreach ($Row in $SqlOutput) {
        if ($Row.Column1) {
            Write-Log "SQL Output: $($Row.Column1)"
        }
    }
    Write-Log "T-SQL script executed successfully."
    Restart-Service -Name MSSQLSERVER -Force
}
catch {
    Write-Log "Error executing T-SQL script: $_"
    Write-Error "Failed to execute T-SQL script: $_"
    exit 1
}

# Verify changes
Write-Log "Verifying changes..."
try {
    $DefaultPaths = Invoke-Sqlcmd -ServerInstance $SqlServer -Query "SELECT SERVERPROPERTY('InstanceDefaultDataPath') AS DefaultData, SERVERPROPERTY('InstanceDefaultLogPath') AS DefaultLog;" -ErrorAction Stop
    $DefaultData = $DefaultPaths.DefaultData
    $DefaultLog = $DefaultPaths.DefaultLog
    Write-Log "Default Data Path: $DefaultData"
    Write-Log "Default Log Path: $DefaultLog"

    $TempDbFiles = Invoke-Sqlcmd -ServerInstance $SqlServer -Query "SELECT name, physical_name FROM sys.master_files WHERE database_id = DB_ID('tempdb');" -ErrorAction Stop
    foreach ($File in $TempDbFiles) {
        Write-Log "TempDB File: $($File.name) at $($File.physical_name)"
    }

    $TempDbDataFileCount = ($TempDbFiles | Where-Object { $_.physical_name -like "*.mdf" -or $_.physical_name -like "*.ndf" }).Count
    Write-Log "Number of TempDB data files: $TempDbDataFileCount"

    $AllTempDbFilesOnF = ($TempDbFiles | Where-Object { $_.physical_name -like "*.mdf" -or $_.physical_name -like "*.ndf" } | ForEach-Object { $_.physical_name -like "F:\MP_TMPDB\*" }).Count -eq $TempDbDataFileCount

    if ($DefaultData -eq "F:\MP_DB1\MSSQL16.MSSQLSERVER\MSSQL\Data\Encrypted\" -and
        $DefaultLog -eq "F:\MP_LOG1\MSSQL16.MSSQLSERVER\MSSQL\Log\Encrypted\" -and
        $TempDbDataFileCount -eq 8 -and
        $AllTempDbFilesOnF) {
        Write-Log "Verification successful: Paths updated and 8 TempDB data files configured on F: drive."
    }
    else {
        Write-Log "Verification failed: Paths or TempDB file count incorrect."
        Write-Log "Expected DefaultData: F:\MP_DB1\MSSQL16.MSSQLSERVER\MSSQL\Data\Encrypted\, Got: $DefaultData"
        Write-Log "Expected DefaultLog: F:\MP_LOG1\MSSQL16.MSSQLSERVER\MSSQL\Log\Encrypted\, Got: $DefaultLog"
        Write-Log "Expected TempDB file count: 8, Got: $TempDbDataFileCount"
        Write-Log "Expected all TempDB data files on F:, Got: $($TempDbFiles.physical_name -join ', ')"
        Write-Error "Verification failed"
        exit 1
    }
}
catch {
    Write-Log "Error verifying changes: $_"
    Write-Error "Failed to verify changes: $_"
    exit 1
}

Write-Log "Script completed successfully."
Write-Host "Configuration completed. Check $LogFile for details."