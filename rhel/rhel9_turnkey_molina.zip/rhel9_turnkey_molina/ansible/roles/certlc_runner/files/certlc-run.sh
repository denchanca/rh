#!/usr/bin/env bash
set -euo pipefail
ENV_FILE="/etc/certlc/certlc.env"
[ -f "$ENV_FILE" ] && source "$ENV_FILE"
: "${AKV_NAME:?AKV_NAME required}"
: "${CERT_OBJECT_NAME:?CERT_OBJECT_NAME required}"
INSTALL_DIR="/opt/certlc"
ZIP_PATH="${INSTALL_DIR}/script_for_not_supported_ARC_on_Linux_distro.zip"
OFFICIAL_RUNNER=""
FALLBACK_LOG="${INSTALL_DIR}/fallback.log"
need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing $1"; exit 1; }; }
need curl; need jq; need openssl; need base64; command -v unzip >/dev/null 2>&1 || true
mkdir -p "$INSTALL_DIR"
if [ -f "$ZIP_PATH" ] && command -v unzip >/dev/null 2>&1; then
  workdir=$(mktemp -d); trap 'rm -rf "$workdir"' EXIT
  unzip -oq "$ZIP_PATH" -d "$workdir"
  OFFICIAL_RUNNER=$(find "$workdir" -type f -name "*.sh" -print | head -n1 || true)
fi
if [ -n "$OFFICIAL_RUNNER" ] && [ -x "$OFFICIAL_RUNNER" ]; then
  echo "[certlc] Running official script: $OFFICIAL_RUNNER"
  bash "$OFFICIAL_RUNNER" || echo "[certlc] Official runner exited non-zero"
  exit 0
fi
echo "[certlc] Using fallback runner aligned with CERTLC guidance" | tee -a "$FALLBACK_LOG"
KV_URL="https://${AKV_NAME}.vault.azure.net"; API="7.4"
TOKEN=$(curl -sS --fail -H "Metadata: true" "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net" | jq -r '.access_token')
AUTH="Authorization: Bearer ${TOKEN}"
TARGET_MODE="${TARGET_MODE:-pem}"
CERT_OUT_PATH="${CERT_OUT_PATH:-/etc/pki/tls/certs/service.crt}"
KEY_OUT_PATH="${KEY_OUT_PATH:-/etc/pki/tls/private/service.key}"
PEM_OUT_PATH="${PEM_OUT_PATH:-/etc/pki/tls/certs/service.pem}"
OWNER="${OWNER:-root}"; GROUP="${GROUP:-root}"; RESTART_SERVICE="${RESTART_SERVICE:-}"
umask 077; changed=0
write_if_changed(){ local path="$1"; local tmp="$2"; if [ -f "$path" ] && cmp -s "$path" "$tmp"; then return 1; fi; install -m 0600 -o "$OWNER" -g "$GROUP" "$tmp" "$path"; return 0; }
if [ "$TARGET_MODE" = "pem" ]; then
  val=$(curl -sS --fail -H "$AUTH" "${KV_URL}/secrets/${CERT_OBJECT_NAME}?api-version=${API}" | jq -r '.value')
  tmp=$(mktemp); printf "%s" "$val" > "$tmp"; if write_if_changed "$PEM_OUT_PATH" "$tmp"; then changed=1; fi
else
  cer=$(curl -sS --fail -H "$AUTH" "${KV_URL}/certificates/${CERT_OBJECT_NAME}?api-version=${API}" | jq -r '.cer' | base64 -d)
  tmpc=$(mktemp); printf "%s" "$cer" > "$tmpc"; if write_if_changed "$CERT_OUT_PATH" "$tmpc"; then changed=1; fi
  key=$(curl -sS --fail -H "$AUTH" "${KV_URL}/secrets/${CERT_OBJECT_NAME}-key?api-version=${API}" | jq -r '.value')
  tmpk=$(mktemp); printf "%s" "$key" > "$tmpk"; if write_if_changed "$KEY_OUT_PATH" "$tmpk"; then changed=1; fi
fi
if [ "$changed" -eq 1 ] && [ -n "$RESTART_SERVICE" ]; then systemctl restart "$RESTART_SERVICE" || true; fi
exit 0
