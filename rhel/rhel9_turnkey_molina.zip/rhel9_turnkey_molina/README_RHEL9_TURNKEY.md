# RHEL 9 Golden Image – README (CERTLC edition)

> **IMPORTANT — TEMPLATE EXAMPLE**
> This package is a **template**. `linux/catalog.json` uses placeholder URLs and SHA-256 values.
> Replace `artifact` URLs with Molina-internal locations and set **exact SHA-256 hashes** before running the pipeline.
> Keep `stage: true` for installers to bake (stage-only). Perform **enrollment post-deploy** via Ansible with AKV-sourced secrets.


**Contents**
- ADO pipeline, Packer templates, scripts, Ansible roles (agent_enroll + certlc_runner), tests, policy guard.
**Run**
1) Update catalog URLs & SHA-256s
2) Queue pipeline
3) Run `ansible/postdeploy.yml` (toggle `enable_certlc` as desired)
