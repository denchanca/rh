# RHEL 9 Golden Image – HOWTO (CERTLC edition)

> **IMPORTANT — TEMPLATE EXAMPLE**
> This package is a **template**. `linux/catalog.json` uses placeholder URLs and SHA-256 values.
> Replace `artifact` URLs with Molina-internal locations and set **exact SHA-256 hashes** before running the pipeline.
> Keep `stage: true` for installers to bake (stage-only). Perform **enrollment post-deploy** via Ansible with AKV-sourced secrets.


## 1) What changed in this edition
This bundle swaps the custom AKV cert sync for **Microsoft’s Certificate Lifecycle (CERTLC)** pattern:
- For RHEL9 (no AKV extension), we **schedule the official CERTLC script** recommended by Microsoft, or fall back to a compatible runner.
- Rotation is **fully runtime**: the image remains immutable; certificates are injected and refreshed from AKV.

## 2) Prereqs
- Azure DevOps Service Connection with RBAC to Shared Image Gallery (SIG) RG and build RG
- SIG exists; target image definitions created (or created once)
- Build agent with internet egress to download Packer (if needed)
- **Managed Identity** enabled on target VMs (system-assigned is fine) with `Key Vault Secrets User` on the target AKV
- AKV contains either a **PEM secret** or a **certificate object + key secret**

## 3) Pipeline Flow
Validate → Build (Gen2/Gen1) → OpenSCAP → Smoke → Publish

## 4) Configure staging catalog
Edit `linux/catalog.json` with Molina URLs and **real SHA-256** hashes (required).

## 5) Post-deploy configuration (Ansible)
Enable **CERTLC** with `enable_certlc: true`. Provide `certlc_zip_url` and `certlc_zip_sha256`, and set AKV variables.

## 6) Security
No secrets in images; MI-based AKV access; files 0600; timer hourly by default.

## 7) Troubleshooting
`systemctl status certlc-run.timer`; check `/var/log/certlc/fallback.log`; verify AKV RBAC.

## 8) Gen1
Enable `useGen1: true` to also build Gen1.
