#!/usr/bin/env bash
set -euo pipefail
usage(){ echo "Usage: $0 --sig-rg RG --sig-name SIG --image-def NAME --location LOC"; exit 1; }
SIG_RG=""; SIG_NAME=""; IMAGE_DEF=""; LOCATION=""
while [ $# -gt 0 ]; do
  case "$1" in
    --sig-rg) SIG_RG="$2"; shift 2;;
    --sig-name) SIG_NAME="$2"; shift 2;;
    --image-def) IMAGE_DEF="$2"; shift 2;;
    --location) LOCATION="$2"; shift 2;;
    *) usage;;
  esac
done
[ -n "$SIG_RG" ] && [ -n "$SIG_NAME" ] && [ -n "$IMAGE_DEF" ] && [ -n "$LOCATION" ] || usage
need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing $1"; exit 1; }; }
need az; need jq
ts=$(date +%s); rg="tmp-rhel9-smoke-$ts"; vm="rhel9-smoke-$ts"
img_version=$(az sig image-version list -g "$SIG_RG" --gallery-name "$SIG_NAME" --gallery-image-definition "$IMAGE_DEF" --query "[].name" -o tsv | sort -V | tail -n1)
[ -n "$img_version" ] || { echo "No versions found for $IMAGE_DEF"; exit 2; }
img_id=$(az sig image-version show -g "$SIG_RG" --gallery-name "$SIG_NAME" --gallery-image-definition "$IMAGE_DEF" --gallery-image-version "$img_version" --query "id" -o tsv)
az group create -n "$rg" -l "$LOCATION" -o none
az vm create -g "$rg" -n "$vm" --image "$img_id" --admin-username azureuser --generate-ssh-keys --public-ip-sku Standard -l "$LOCATION" -o none
az vm run-command invoke -g "$rg" -n "$vm" --command-id RunShellScript --scripts "set -euxo pipefail; ls -la /opt/stage/Tools; systemctl is-enabled auditd; systemctl is-active auditd; getenforce"
echo "EXPORT_VM_INFO RG=$rg VM=$vm"
az group delete -n "$rg" --yes --no-wait
