#!/usr/bin/env bash
set -euo pipefail
usage(){ echo "Usage: $0 --rg RG --vm VM"; exit 1; }
RG=""; VM=""
while [ $# -gt 0 ]; do
  case "$1" in
    --rg) RG="$2"; shift 2;;
    --vm) VM="$2"; shift 2;;
    *) usage;;
  esac
done
[ -n "$RG" ] && [ -n "$VM" ] || usage
need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing $1"; exit 1; }; }
need az
az vm run-command invoke -g "$RG" -n "$VM" --command-id RunShellScript --scripts   "set -euxo pipefail; dnf -y install openscap-scanner scap-security-guide;    oscap xccdf eval --profile xccdf_org.ssgproject.content_profile_minimal    --results-arf /root/arf.xml --report /root/openscap.html /usr/share/xml/scap/ssg/content/ssg-rhel9-ds.xml || exit 3;    test -f /root/openscap.html && echo 'OpenSCAP report generated'"
