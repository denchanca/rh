#!/usr/bin/env bash
set -euo pipefail
CAT="${1:-./linux/catalog.json}"
need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing $1"; exit 1; }; }
need jq
[ -f "$CAT" ] || { echo "No catalog at $CAT"; exit 1; }
ALLOWLIST="checkmk appdynamics crowdstrike tanium splunkuf"
MAX_MB="${MAX_CATALOG_MB:-800}"
total=0
jq -r '.[] | @base64' "$CAT" | while read -r row; do
  _jq(){ echo "$row" | base64 -d | jq -r "$1"; }
  id=$(_jq '.id'); sha=$(_jq '.sha256'); url=$(_jq '.artifact'); sz=$(_jq '.sizeMB // 0'); stage=$(_jq '.stage // true')
  echo "$ALLOWLIST" | tr ' ' '\n' | grep -qx "$id" || { echo "Not allowed: $id"; exit 2; }
  [ -n "$sha" ] && [ "$sha" != "<REPLACE_WITH_SHA256>" ] || { echo "Placeholder/missing SHA for $id"; exit 2; }
  echo "$url" | grep -q '^https://' || { echo "Non-HTTPS URL for $id"; exit 2; }
  total=$(( total + sz ))
done
if [ "$MAX_MB" -gt 0 ] && [ "$total" -gt "$MAX_MB" ]; then
  echo "Catalog size ${total}MB exceeds budget ${MAX_MB}MB"; exit 2
fi
echo "Policy guard passed."
