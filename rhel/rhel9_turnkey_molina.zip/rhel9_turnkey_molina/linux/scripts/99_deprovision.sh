#!/usr/bin/env bash
set -euo pipefail
waagent -deprovision+user -force || true
sync
