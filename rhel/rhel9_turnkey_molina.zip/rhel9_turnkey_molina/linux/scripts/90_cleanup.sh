#!/usr/bin/env bash
set -euo pipefail
dnf -y clean all
rm -rf /var/cache/dnf/*
truncate -s 0 /etc/machine-id || true
rm -f /var/lib/dbus/machine-id || true
ln -s /etc/machine-id /var/lib/dbus/machine-id || true
sed -i 's/^Provisioning.MonitorHostName=.*/Provisioning.MonitorHostName=y/' /etc/waagent.conf || true
