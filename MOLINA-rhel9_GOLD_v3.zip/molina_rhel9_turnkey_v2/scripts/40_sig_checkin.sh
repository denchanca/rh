#!/usr/bin/env bash
set -euo pipefail

usage(){
cat <<EOF
Usage: $0 --resource-group RG --managed-image IMG --sig-name SIG \
          --sig-image-def IMAGE_DEF --sig-version VERSION [--location LOC]
Publishes an Azure Managed Image to a Shared Image Gallery as a new version.
Requires 'az' CLI with appropriate RBAC.
EOF
}

# parse args
RG=""; IMG=""; SIG_NAME=""; SIG_DEF=""; SIG_VER=""; LOC="${LOCATION:-}"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --resource-group) RG="$2"; shift 2;;
    --managed-image) IMG="$2"; shift 2;;
    --sig-name) SIG_NAME="$2"; shift 2;;
    --sig-image-def) SIG_DEF="$2"; shift 2;;
    --sig-version) SIG_VER="$2"; shift 2;;
    --location) LOC="$2"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown arg $1"; usage; exit 1;;
  esac
done

[[ -z "$RG" || -z "$IMG" || -z "$SIG_NAME" || -z "$SIG_DEF" || -z "$SIG_VER" ]] && { usage; exit 1; }

echo "[sig] Publishing $IMG to SIG:$SIG_NAME/$SIG_DEF version $SIG_VER"
if [[ -n "$LOC" ]]; then
  az sig image-version create \
    -g "$RG" --gallery-name "$SIG_NAME" --gallery-image-definition "$SIG_DEF" \
    --gallery-image-version "$SIG_VER" --managed-image "$IMG" --location "$LOC" -o table
else
  az sig image-version create \
    -g "$RG" --gallery-name "$SIG_NAME" --gallery-image-definition "$SIG_DEF" \
    --gallery-image-version "$SIG_VER" --managed-image "$IMG" -o table
fi

echo "[sig] Done."
