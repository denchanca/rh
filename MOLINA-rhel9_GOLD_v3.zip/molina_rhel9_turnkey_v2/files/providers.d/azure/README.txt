Place Azure-specific installer binaries here, e.g., tanium/*.rpm, crowdstrike/*.rpm
