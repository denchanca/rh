Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Start-Transcript -Path "C:\Windows\Temp\img-20_prestage.log" -Append

$manifestPath = $env:ARTIFACT_MANIFEST
if ([string]::IsNullOrWhiteSpace($manifestPath)) { $manifestPath = 'C:\Stage\manifest.json' }
if (!(Test-Path $manifestPath)) { throw "Artifact manifest not found at $manifestPath" }

$manifest = Get-Content $manifestPath | ConvertFrom-Json

# Ensure Stage directories exist
New-Item -Path 'C:\Stage' -ItemType Directory -Force | Out-Null
New-Item -Path 'C:\Stage\lgpo' -ItemType Directory -Force | Out-Null

function Get-FileSha256([string]$Path) {
    return (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToUpper()
}

foreach ($item in $manifest) {
    if (-not $item.name -or -not $item.url -or -not $item.sha256) {
        throw "Manifest entry missing required fields: $($item | ConvertTo-Json -Compress)"
    }
    $dst = Join-Path 'C:\Stage' $item.name
    Write-Host "Downloading $($item.name)"
    Invoke-WebRequest -Uri $item.url -OutFile $dst -UseBasicParsing

    $actual = Get-FileSha256 -Path $dst
    $expected = $item.sha256.ToUpper()
    if ($actual -ne $expected) {
        throw "Hash mismatch for $($item.name). expected=$expected actual=$actual"
    }

    if ($item.authenticode -eq $true) {
        $sig = Get-AuthenticodeSignature -FilePath $dst
        if ($sig.Status -ne 'Valid') {
            throw "Authenticode signature invalid for $($item.name): $($sig.Status)"
        }
    }

    if ($item.name -ieq 'LGPO.exe') {
        Copy-Item $dst -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
    }
}

# Optional silent installs of OS-level prerequisites if present in Stage
$ndp = 'C:\Stage\NDP481-Web.exe'
if (Test-Path $ndp) {
    Write-Host "Installing .NET 4.8.1"
    Start-Process $ndp -ArgumentList '/passive /norestart' -Wait
    if ($LASTEXITCODE -ne 0) { throw ".NET 4.8.1 installer returned $LASTEXITCODE" }
}

$vc = 'C:\Stage\vc_redist.x64.exe'
if (Test-Path $vc) {
    Write-Host "Installing VC++ Redistributable x64"
    Start-Process $vc -ArgumentList '/quiet /norestart' -Wait
    if ($LASTEXITCODE -ne 0) { throw "VC++ Redistributable installer returned $LASTEXITCODE" }
}

# NOTE: Do NOT enroll or start agents (CrowdStrike/Tanium/Splunk) here.
# Only stage their installers. Enrollment occurs post-deploy with environment secrets.

Stop-Transcript
