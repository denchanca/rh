# Placeholder: install agents (CrowdStrike/Tanium/Splunk) pre-staged
