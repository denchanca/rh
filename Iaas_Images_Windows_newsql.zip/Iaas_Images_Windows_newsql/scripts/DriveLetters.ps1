# ReassignDriveLetters.ps1 - Run as Administrator at startup
# If D: is labeled 'DataE', reassigns removable media drives (D: or higher) to unused letters using diskpart, then increments fixed disk drive letters by one

Set-ExecutionPolicy Bypass -Scope Process -Force

# Function to get the next available drive letter
function Get-NextAvailableLetter {
    param(
        [string]$StartLetter
    )
    $usedLetters = (Get-Volume | Where-Object { $_.DriveLetter } | Select-Object -ExpandProperty DriveLetter) -join ''
    $current = [int][char]$StartLetter
    while ($current -le [int][char]'Z' -and $usedLetters -contains [char]$current) {
        $current++
    }
    if ($current -gt [int][char]'Z') {
        Write-Error "No available drive letters found."
        return $null
    }
    return [char]$current
}

# Function to reassign drive letter for removable media (e.g., CD-ROM) using diskpart
function Reassign-RemovableDriveLetter {
    param(
        [string]$CurrentLetter,
        [string]$TargetLetter
    )
    
    $volume = Get-Volume | Where-Object { $_.DriveLetter -eq $CurrentLetter }
    if (-not $volume) {
        Write-Warning "Volume on $CurrentLetter`: not found. Skipping."
        return $true
    }
    
    if ($volume.DriveType -eq 'Fixed') {
        Write-Warning "Drive $CurrentLetter`: is a fixed disk, not removable. Skipping."
        return $true
    }
    
    if ($CurrentLetter -eq $TargetLetter) {
        Write-Host "Drive $CurrentLetter`: already assigned to $TargetLetter`: - no change needed."
        return $true
    }
    
    # Check for conflicts
    $conflict = Get-Volume | Where-Object { $_.DriveLetter -eq $TargetLetter }
    if ($conflict) {
        Write-Error "Target letter $TargetLetter`: is in use by '$($conflict.FileSystemLabel)' (DriveType: $($conflict.DriveType)). Manual intervention required."
        return $false
    }
    
    # Use diskpart to reassign CD-ROM drive letter
    $diskpartScript = @"
select volume $CurrentLetter
assign letter=$TargetLetter
"@
    $diskpartScript | Out-File -FilePath "$env:TEMP\diskpart.txt" -Encoding ASCII
    try {
        $output = diskpart /s "$env:TEMP\diskpart.txt" 2>&1
        if ($output -match "successfully assigned the drive letter") {
            Write-Host "Reassigned removable drive from ${CurrentLetter}: to $TargetLetter`:."
            return $true
        } else {
            Write-Error "diskpart failed to reassign $CurrentLetter`: to $TargetLetter`:. Output: $output"
            return $false
        }
    }
    catch {
        Write-Error "Failed to reassign removable drive $CurrentLetter`: $($_.Exception.Message)"
        return $false
    }
    finally {
        Remove-Item -Path "$env:TEMP\diskpart.txt" -ErrorAction SilentlyContinue
    }
}

# Function to reassign drive letter for fixed disks
function Reassign-FixedDriveLetter {
    param(
        [string]$CurrentLetter,
        [string]$TargetLetter
    )
    
    $volume = Get-Volume | Where-Object { $_.DriveLetter -eq $CurrentLetter }
    if (-not $volume) {
        Write-Warning "Volume on $CurrentLetter`: not found. Skipping."
        return $true
    }
    
    if ($volume.DriveType -ne 'Fixed') {
        Write-Warning "Drive $CurrentLetter`: is not a fixed disk (DriveType: $($volume.DriveType)). Skipping."
        return $true
    }
    
    $label = $volume.FileSystemLabel
    if ($CurrentLetter -eq $TargetLetter) {
        Write-Host "Volume '$label' already assigned to $TargetLetter`: - no change needed."
        return $true
    }
    
    # Check for conflicts
    $conflict = Get-Volume | Where-Object { $_.DriveLetter -eq $TargetLetter }
    if ($conflict) {
        Write-Error "Target letter $TargetLetter`: is in use by '$($conflict.FileSystemLabel)' (DriveType: $($conflict.DriveType)). Manual intervention required."
        return $false
    }
    
    # Get the partition for the volume
    $partition = Get-Partition | Where-Object { $_.DriveLetter -eq $CurrentLetter }
    if (-not $partition) {
        Write-Warning "Partition for '$label' ($CurrentLetter`:) not found. Skipping."
        return $true
    }
    
    try {
        Set-Partition -InputObject $partition -NewDriveLetter $TargetLetter -Confirm:$false
        Write-Host "Reassigned '$label' from ${CurrentLetter}: to $TargetLetter`:."
        return $true
    }
    catch {
        Write-Error "Failed to reassign '$label': $($_.Exception.Message)"
        return $false
    }
}

# Check if D: is labeled 'DataE'
$dVolume = Get-Volume | Where-Object { $_.DriveLetter -eq 'D' -and $_.FileSystemLabel -eq 'DataE' }

if ($dVolume) {
    Write-Host "D: is labeled 'DataE'. Proceeding with drive letter reassignments..."
    
    # Step 1: Reassign removable media drives to unused letters
    $removableDrives = Get-Volume | Where-Object { $_.DriveLetter -ge 'D' -and $_.DriveLetter -and $_.DriveType -ne 'Fixed' } | 
                       Sort-Object DriveLetter -Descending
    
    $success = $true
    if ($removableDrives) {
        Write-Host "`nReassigning removable media drives..."
        # Find the highest used drive letter to start assigning removable media
        $highestLetter = (Get-Volume | Where-Object { $_.DriveLetter } | Sort-Object DriveLetter -Descending | Select-Object -First 1).DriveLetter
        $nextLetter = [char]([int][char]$highestLetter + 1)
        
        foreach ($drive in $removableDrives) {
            $currentLetter = $drive.DriveLetter
            $targetLetter = Get-NextAvailableLetter -StartLetter $nextLetter
            if (-not $targetLetter) {
                $success = $false
                break
            }
            
            $result = Reassign-RemovableDriveLetter -CurrentLetter $currentLetter -TargetLetter $targetLetter
            if (-not $result) {
                $success = $false
                break
            }
            $nextLetter = [char]([int][char]$targetLetter + 1)
        }
    }
    
    # Step 2: Reassign fixed disk drives, if removable media reassignment succeeded
    if ($success) {
        Write-Host "`nReassigning fixed disk drives..."
        $fixedDrives = Get-Volume | Where-Object { $_.DriveLetter -ge 'D' -and $_.DriveLetter -and $_.DriveType -eq 'Fixed' } | 
                       Sort-Object DriveLetter -Descending
        
        foreach ($drive in $fixedDrives) {
            $currentLetter = $drive.DriveLetter
            $targetLetter = [char]([int][char]$currentLetter + 1)
            
            # Ensure target letter is within valid range (A-Z)
            if ($targetLetter -gt 'Z') {
                Write-Error "Cannot reassign $currentLetter`: to $targetLetter`: - exceeds valid drive letter range."
                $success = $false
                break
            }
            
            $result = Reassign-FixedDriveLetter -CurrentLetter $currentLetter -TargetLetter $targetLetter
            if (-not $result) {
                $success = $false
                break
            }
        }
    }
    
    # Verify final assignments
    Write-Host "`nFinal drive assignments:"
    Get-Volume | Where-Object { $_.DriveLetter -ge 'D' -and $_.DriveLetter } | 
        Select-Object DriveLetter, FileSystemLabel, DriveType, Size | 
        Sort-Object DriveLetter | Format-Table -AutoSize
    
    if ($success) {
        Write-Host "`nAll reassignments successful. Restart VM for SQL Server startup..."
    } else {
        Write-Error "One or more reassignments failed. VM not restarted."
        exit 1
    }
} else {
    Write-Host "D: is not labeled 'DataE'. No drive letter reassignments performed."
    # Verify current assignments
    Write-Host "`nCurrent drive assignments:"
    Get-Volume | Where-Object { $_.DriveLetter -ge 'D' -and $_.DriveLetter } | 
        Select-Object DriveLetter, FileSystemLabel, DriveType, Size | 
        Sort-Object DriveLetter | Format-Table -AutoSize
    exit 0
}