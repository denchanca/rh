# Install SQL Developer Edition
$sqlZipName = 'SQLServer_DEV_2022.zip'
$sqlExtractPath = 'C:\Stage\SQLServer_DEV_2022'
$sqlZipPath = Join-Path 'C:\Stage' $sqlZipName

if (Test-Path $sqlZipPath) {
    Write-Host "Extracting SQL Server ZIP..."
    Expand-Archive -Path $sqlZipPath -DestinationPath $sqlExtractPath -Force
    Write-Host "SQL Server ZIP extracted to $sqlExtractPath"

    # Search for setup.exe recursively
    $sqlSetupExe = Get-ChildItem -Path $sqlExtractPath -Filter 'setup.exe' -Recurse | Select-Object -First 1

    if ($sqlSetupExe) {
        Write-Host "Running SQL Server setup..."

        $saUser = "sa"
        $saPassword = "P@ssword@12345"  # Replace with secure password
        $installArgs = "/Q /ACTION=Install /FEATURES=SQL /INSTANCENAME=MSSQLSERVER /SECURITYMODE=SQL /SAPWD=`"$saPassword`" /SQLSYSADMINACCOUNTS=`"$env:USERNAME`" /IACCEPTSQLSERVERLICENSETERMS"

        Start-Process -FilePath $sqlSetupExe.FullName -ArgumentList $installArgs -Wait
        Write-Host "SQL Server installation complete."
    } else {
        Write-Warning "setup.exe not found in extracted SQL ZIP"
    }
} else {
    Write-Warning "SQL ZIP not found at $sqlZipPath"
}