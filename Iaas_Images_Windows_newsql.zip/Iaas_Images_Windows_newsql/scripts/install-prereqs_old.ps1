Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
 
Start-Transcript -Path 'C:\Windows\Temp\img-20_prestage.log' -Append
try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
 
    # Resolve manifest path and read (tolerate missing/blank/{} by treating as empty)
    $manifestPath = $env:ARTIFACT_MANIFEST
    if ([string]::IsNullOrWhiteSpace($manifestPath)) { $manifestPath = 'C:\Stage\manifest.json' }
 
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        Write-Host "Manifest not found at $manifestPath - treating as empty"
        $manifest = @()
    } else {
        $raw = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction SilentlyContinue
        if ([string]::IsNullOrWhiteSpace($raw)) {
            Write-Host "Manifest file is empty - treating as empty array"
            $manifest = @()
        } else {
            try { 
                $parsed = $raw | ConvertFrom-Json 
                Write-Host "Successfully parsed manifest JSON"
            } catch { 
                throw "Artifact manifest at $manifestPath is not valid JSON: $($_.Exception.Message)" 
            }
            
            # Fix: Completely safe array handling
            if ($null -eq $parsed) {
                $manifest = @()
            } else {
                # Force to array using the array subexpression operator
                $manifest = @($parsed)
                
                # Check if it's a single empty object - use try-catch for safety
                if ($manifest.Length -eq 1) {
                    try {
                        $firstItem = $manifest[0]
                        if ($null -ne $firstItem -and $null -ne $firstItem.PSObject) {
                            $propCount = 0
                            try {
                                $propCount = ($firstItem.PSObject.Properties | Measure-Object).Count
                            } catch {
                                $propCount = 0
                            }
                            
                            if ($propCount -eq 0) {
                                Write-Host "Manifest contains empty object - treating as empty array"
                                $manifest = @()
                            }
                        }
                    } catch {
                        # If we can't check properties, assume it's valid
                        Write-Host "Could not analyze manifest object properties - proceeding"
                    }
                }
            }
        }
    }
 
    Write-Host "Manifest contains $($manifest.Length) items"
    
    # Ensure Stage dirs
    New-Item -Path 'C:\Stage' -ItemType Directory -Force | Out-Null
    New-Item -Path 'C:\Stage\lgpo' -ItemType Directory -Force | Out-Null

    # Process each manifest item
    foreach ($item in $manifest) {
        if (-not $item.name -or -not $item.url) {
            Write-Warning "Skipping invalid manifest entry: $($item | ConvertTo-Json -Compress)"
            continue
        }
        
        $dst = Join-Path 'C:\Stage' $item.name
        Write-Host "Downloading $($item.name) from $($item.url)"
        
        try {
            Invoke-WebRequest -Uri $item.url -OutFile $dst -UseBasicParsing
            Write-Host "Successfully downloaded $($item.name)"
        }
        catch {
            Write-Warning "Failed to download $($item.name): $($_.Exception.Message) - skipping"
            continue
        }

        # Handle gpo-bkp.zip extraction and LGPO.exe copying
        if ($item.name -ieq 'gpo-bkp.zip') {
            Write-Host "Extracting $($item.name)"
            $extractPath = 'C:\Stage\extracted'
            New-Item -Path $extractPath -ItemType Directory -Force | Out-Null
            
            # Extract the ZIP file
            Expand-Archive -Path $dst -DestinationPath $extractPath -Force
            Write-Host "Successfully extracted $($item.name) to $extractPath"
            
            # Replace this section in your script:
            # Look for LGPO.exe in the extracted files (search recursively)
            $lgpoFiles = Get-ChildItem -Path $extractPath -Name 'LGPO.exe' -Recurse -ErrorAction SilentlyContinue

            if ($lgpoFiles) {
            $lgpoSource = Get-ChildItem -Path $extractPath -Filter 'LGPO.exe' -Recurse | Select-Object -First 1
            Copy-Item -Path $lgpoSource.FullName -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
            Write-Host "Copied LGPO.exe from extracted files to C:\Stage\lgpo\LGPO.exe"
            } else {
            Write-Warning "LGPO.exe not found in extracted gpo-bkp.zip contents"
            }
        }
        
        # Handle standalone LGPO.exe (if provided separately)
        if ($item.name -ieq 'LGPO.exe') {
            Copy-Item -LiteralPath $dst -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
            Write-Host "Copied LGPO.exe to lgpo directory"
        }

      

        if ($item.name -ieq 'Tanium.zip') {
            Write-Host "Extracting $($item.name)"
            $taniumextractPath = 'C:\Stage\'
            
            # Extract the ZIP file
            Expand-Archive -Path $dst -DestinationPath $taniumextractPath -Force
            Write-Host "Successfully extracted $($item.name) to $taniumextractPath"

            Write-Host 'Installing Tanium'
            Start-Process -FilePath "C:\Stage\Tanium\TaniumSetupClient.exe" -ArgumentList '/quiet /norestart' -Wait


        
        }

        if ($item.name -ieq 'SSMS-Setup-ENU.exe') {

        Write-Host 'Installing SSMS'
        Start-Process -FilePath "C:\Stage\SSMS-Setup-ENU.exe" -ArgumentList '/quiet /norestart' -Wait
        Write-Host 'Successfully installed SSMS'

    }

        if ($item.name -ieq 'NDP48-DevPack-ENU.exe') {

            Write-Host 'Installing .Net 4.8'
            Start-Process -FilePath "C:\Stage\NDP48-DevPack-ENU.exe" -ArgumentList '/quiet /norestart' -Wait
            Write-Host 'Successfully installed .Net 4.8'

        }



    }
 
    # Optional silent installs if staged
    #$ndp = 'C:\Stage\NDP481-Web.exe'
    #if (Test-Path -LiteralPath $ndp) {
    #    Write-Host 'Installing .NET 4.8.1'
    #    $p = Start-Process -FilePath $ndp -ArgumentList '/passive /norestart' -Wait -PassThru
    #    if ($p.ExitCode -ne 0) { throw ".NET 4.8.1 installer returned $($p.ExitCode)" }
    #}
 
    
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Install check-mk-agent
$checkmkInstaller = Get-ChildItem -Path "C:\Stage" -Filter "*check-mk*.msi" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($checkmkInstaller) {
    Write-Host "Installing check-mk-agent from: $($checkmkInstaller.FullName)"
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$($checkmkInstaller.FullName)`" /quiet /norestart" -Wait -NoNewWindow
} else {
    Write-Warning "No check-mk-agent installer found in C:\Stage"
}

# Install Splunk
$splunkInstaller = Get-ChildItem -Path "C:\Stage" -Filter "*splunk*.msi" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($splunkInstaller) {
    Write-Host "Installing Splunk from: $($splunkInstaller.FullName)"
    $splunkArgs = "DEPLOYMENT_SERVER=10.224.20.111:8089 AGREETOLICENSE=Yes SPLUNKUSERNAME=admin SPLUNKPASSWORD=changeme /quiet"
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$($splunkInstaller.FullName)`" $splunkArgs" -Wait -NoNewWindow
} else {
    Write-Warning "No Splunk installer found in C:\Stage"
}

    Write-Host ('Prestage complete. Items processed: {0}' -f $manifest.Length)
}
catch {
    Write-Error "Prestage script failed: $($_.Exception.Message)"
    throw
}
finally {
    Stop-Transcript | Out-Null
}