[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$pwshInstallerUrl = "https://github.com/PowerShell/PowerShell/releases/download/v7.5.3/PowerShell-7.5.3-win-x64.msi"
$pwshInstallerPath = "C:\Stage\PowerShell-7.5.3-win-x64.msi"

Write-Host "Downloading PowerShell 7.5.3..."
Invoke-WebRequest -Uri $pwshInstallerUrl -OutFile $pwshInstallerPath

Write-Host "Installing PowerShell 7.5.3..."
Start-Process -FilePath $pwshInstallerPath -ArgumentList "/quiet" -Wait

Write-Host "PowerShell 7 installation complete."