# Requires PowerShell 7+
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

param (
    [string]$ManifestPath = $env:ARTIFACT_MANIFEST
)

if ([string]::IsNullOrWhiteSpace($ManifestPath)) {
    $ManifestPath = 'C:\Stage\manifest.json'
}

Write-Host "Using manifest path: $ManifestPath"

# Load manifest
if (-not (Test-Path -LiteralPath $ManifestPath)) {
    Write-Host "Manifest not found - treating as empty"
    $manifest = @()
} else {
    $raw = Get-Content -LiteralPath $ManifestPath -Raw -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($raw)) {
        Write-Host "Manifest file is empty - treating as empty array"
        $manifest = @()
    } else {
        try {
            $parsed = $raw | ConvertFrom-Json
            Write-Host "Successfully parsed manifest JSON"
        } catch {
            throw "Artifact manifest at $ManifestPath is not valid JSON: $($_.Exception.Message)"
        }

        $manifest = @($parsed)
        if ($manifest.Length -eq 1) {
            try {
                $firstItem = $manifest[0]
                $propCount = ($firstItem.PSObject.Properties | Measure-Object).Count
                if ($propCount -eq 0) {
                    Write-Host "Manifest contains empty object - treating as empty array"
                    $manifest = @()
                }
            } catch {
                Write-Host "Could not analyze manifest object properties - proceeding"
            }
        }
    }
}

Write-Host "Manifest contains $($manifest.Length) items"

# Create staging directories
New-Item -Path 'C:\Stage' -ItemType Directory -Force | Out-Null
New-Item -Path 'C:\Stage\lgpo' -ItemType Directory -Force | Out-Null

# Download files sequentially
foreach ($item in $manifest) {
    if (-not $item.name -or -not $item.url) {
        Write-Warning "Skipping invalid manifest entry: $($item | ConvertTo-Json -Compress)"
        continue
    }

    $dst = Join-Path 'C:\Stage' $item.name
    Write-Host "Downloading $($item.name) from $($item.url)"

    try {
        Invoke-RestMethod -Uri $item.url -OutFile $dst
        Write-Host "Successfully downloaded ${dst}"
    } catch {
        Write-Warning "Failed to download ${dst}: ${($_.Exception.Message)}"
    }
}

# Post-download processing
foreach ($item in $manifest) {
    $dst = Join-Path 'C:\Stage' $item.name

    if ($item.name -ieq 'gpo-bkp.zip') {
        Write-Host "Extracting $($item.name)"
        $extractPath = 'C:\Stage\extracted'
        New-Item -Path $extractPath -ItemType Directory -Force | Out-Null
        Expand-Archive -Path $dst -DestinationPath $extractPath -Force
        Write-Host "Extracted to $extractPath"

        $lgpoSource = Get-ChildItem -Path $extractPath -Filter 'LGPO.exe' -Recurse | Select-Object -First 1
        if ($lgpoSource) {
            Copy-Item -Path $lgpoSource.FullName -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
            Write-Host "Copied LGPO.exe to C:\Stage\lgpo"
        } else {
            Write-Warning "LGPO.exe not found in extracted contents"
        }
    }

    if ($item.name -ieq 'LGPO.exe') {
        Copy-Item -LiteralPath $dst -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
        Write-Host "Copied LGPO.exe to lgpo directory"
    }
}

# Install Tanium if present
$taniumInstaller = 'C:\Stage\TaniumSetupClient.exe'
if (Test-Path $taniumInstaller) {
    Write-Host 'Installing Tanium...'
    Start-Process -FilePath $taniumInstaller -ArgumentList '/quiet /norestart' -Wait
    Write-Host 'Tanium installation complete.'
} else {
    Write-Warning "Tanium installer not found at $taniumInstaller"
}

Write-Host "Prestage complete. Items processed: $($manifest.Length)"
