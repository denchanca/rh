# Install SQL Server Developer Edition (2022)
$sqlZipPath = 'C:\Stage\SQLServer_DEV_2022.zip'
$sqlExtractPath = 'C:\Stage\SQLServer_DEV'

# Configuration variables
$AdminUser = "mmc\AzurBLDAD_AutoSVC01"
$SAPassword = "P@ssword@12345"
$svcPassword = "JtW52n0RmLk&tN1"

Write-Host "Starting SQL Server Developer installation..."

# Add service account to local Administrators
try {
    Add-LocalGroupMember -Group "Administrators" -Member $AdminUser -ErrorAction SilentlyContinue
    Write-Host "Added $AdminUser to local Administrators"
} catch {
    Write-Warning "Could not add service account to Administrators: $_"
}

# Extract and install SQL Server
if (Test-Path $sqlZipPath) {
    Write-Host "Extracting SQL Server..."
    Expand-Archive -Path $sqlZipPath -DestinationPath $sqlExtractPath -Force
    
    # Find setup.exe
    $setup = Get-ChildItem -Path $sqlExtractPath -Filter 'setup.exe' -Recurse | Select-Object -First 1
    
    if ($setup) {
        Write-Host "Found SQL Server setup at: $($setup.FullName)"
        Write-Host "Installing SQL Server Developer Edition (15-30 minutes)..."
        
        # Direct installation arguments (no config file needed)
        $args = @(
            "/Q",
            "/ACTION=Install",
            "/FEATURES=SQLENGINE",
            "/INSTANCENAME=MSSQLSERVER",
            "/SQLSYSADMINACCOUNTS=`"BUILTIN\Administrators`"",
            "/SAPWD=`"$SAPassword`"",
            "/SECURITYMODE=Mixed",
            "/SQLSVCACCOUNT=`"NT Service\MSSQLSERVER`"",
            "/AGTSVCACCOUNT=`"NT Service\SQLSERVERAGENT`"",
            "/SQLSVCINSTANTFILEINIT=True",
            "/TCPENABLED=1",
            "/NPENABLED=0",
            "/BROWSERSVCSTARTUPTYPE=Disabled",
            "/UPDATEENABLED=False",
            "/IACCEPTSQLSERVERLICENSETERMS"
        )
        
        Write-Host "Installation arguments:"
        foreach ($arg in $args) {
            Write-Host "  $arg"
        }
        
        $process = Start-Process -FilePath $setup.FullName -ArgumentList $args -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -eq 0) {
            Write-Host "SQL Server installed successfully!" -ForegroundColor Green
            Write-Host "Configuration:" -ForegroundColor Cyan
            Write-Host "  Instance: MSSQLSERVER" -ForegroundColor Gray
            Write-Host "  SA Password: $SAPassword" -ForegroundColor Gray
            Write-Host "  Service Account: NT Service\MSSQLSERVER" -ForegroundColor Gray
            Write-Host "  Features: SQL Database Engine" -ForegroundColor Gray
            
            # Verify and start SQL Server service
            try {
                $sqlService = Get-Service -Name 'MSSQLSERVER' -ErrorAction Stop
                if ($sqlService.Status -ne "Running") {
                    Write-Host "Starting SQL Server service..."
                    Start-Service -Name 'MSSQLSERVER'
                }
                Write-Host "SQL Server service is running" -ForegroundColor Green
                
                # Add domain user to sysadmin role if needed
                try {
                    Write-Host "Adding domain user to sysadmin role..."
                    $sqlCmd = "CREATE LOGIN [$AdminUser] FROM WINDOWS; ALTER SERVER ROLE sysadmin ADD MEMBER [$AdminUser];"
                    sqlcmd -S localhost -U sa -P "$SAPassword" -Q "$sqlCmd" -ErrorAction Stop
                    Write-Host "Successfully added $AdminUser to sysadmin role" -ForegroundColor Green
                } catch {
                    Write-Warning "Could not add domain user to sysadmin role: $($_.Exception.Message)"
                }
            } catch {
                Write-Warning "Could not verify/start SQL Server service: $($_.Exception.Message)"
            }
            
        } elseif ($process.ExitCode -eq 3010) {
            Write-Host "SQL Server installation completed successfully but requires reboot" -ForegroundColor Yellow
        } else {
            Write-Error "SQL Server installation failed with exit code: $($process.ExitCode)"
            Write-Host "Error Code Analysis:" -ForegroundColor Red
            Write-Host "  Exit Code: $($process.ExitCode)" -ForegroundColor Red
            Write-Host "  Hex Code: 0x$([Convert]::ToString([uint32]$process.ExitCode, 16).ToUpper())" -ForegroundColor Red
            
            # Try to find and display setup logs
            $logPaths = @(
                "C:\Program Files\Microsoft SQL Server\*\Setup Bootstrap\Log\Summary.txt",
                "C:\Program Files\Microsoft SQL Server\*\Setup Bootstrap\Log\Detail.txt"
            )
            
            foreach ($logPath in $logPaths) {
                $logs = Get-ChildItem -Path $logPath -ErrorAction SilentlyContinue
                if ($logs) {
                    Write-Host "Setup log ($($logs[0].Name)):" -ForegroundColor Yellow
                    Get-Content $logs[0].FullName | Select-Object -Last 10 | ForEach-Object { 
                        Write-Host "  $_" -ForegroundColor Gray 
                    }
                    break
                }
            }
            throw "SQL Server installation failed with exit code: $($process.ExitCode)"
        }
    } else {
        throw "setup.exe not found in extracted files at: $sqlExtractPath"
    }
    
    # Cleanup extracted files
    Write-Host "Cleaning up installation files..."
    try {
        Remove-Item -Path $sqlExtractPath -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "Cleanup completed" -ForegroundColor Green
    } catch {
        Write-Warning "Failed to cleanup: $($_.Exception.Message)"
    }
} else {
    throw "SQL Server ZIP not found at $sqlZipPath"
}

Write-Host "SQL Server Developer installation process completed!" -ForegroundColor Green