Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Start-Transcript -Path "C:\Windows\Temp\img-99_sysprep.log" -Append

$sysprep = "$env:SystemRoot\System32\Sysprep\Sysprep.exe"
& $sysprep /oobe /generalize /quiet /quit
Start-Sleep -Seconds 10
if ($LASTEXITCODE -ne 0) {
  $err = "$env:SystemRoot\System32\Sysprep\Panther\setuperr.log"
  if (Test-Path $err) { Get-Content $err | Write-Host }
  throw "Sysprep failed with exit code $LASTEXITCODE"
}

Stop-Transcript
