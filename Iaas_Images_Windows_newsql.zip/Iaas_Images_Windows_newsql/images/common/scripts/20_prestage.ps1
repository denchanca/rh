# img-20_prestage.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Start-Transcript -Path 'C:\Windows\Temp\img-20_prestage.log' -Append
try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

    # Resolve manifest path and read (tolerate missing/blank/{} by treating as empty)
    $manifestPath = $env:ARTIFACT_MANIFEST
    if ([string]::IsNullOrWhiteSpace($manifestPath)) { $manifestPath = 'C:\Stage\manifest.json' }

    if (-not (Test-Path -LiteralPath $manifestPath)) {
        $manifest = @()
    } else {
        $raw = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction SilentlyContinue
        if ([string]::IsNullOrWhiteSpace($raw)) {
            $manifest = @()
        } else {
            try { $parsed = $raw | ConvertFrom-Json } catch { throw "Artifact manifest at $manifestPath is not valid JSON: $($_.Exception.Message)" }
            $manifest = @($parsed)
            if ($manifest.Count -eq 1 -and $manifest[0].psobject.Properties.Count -eq 0) { $manifest = @() }
        }
    }

    # Ensure Stage dirs
    New-Item -Path 'C:\Stage' -ItemType Directory -Force | Out-Null
    New-Item -Path 'C:\Stage\lgpo' -ItemType Directory -Force | Out-Null

    function Get-FileSha256 {
        [CmdletBinding()]
        param([Parameter(Mandatory)][string]$Path)
        (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToUpperInvariant()
    }

    foreach ($item in $manifest) {
        if (-not $item.name -or -not $item.url -or -not $item.sha256) {
            throw ("Manifest entry missing required fields: {0}" -f ($item | ConvertTo-Json -Compress))
        }
        $dst = Join-Path 'C:\Stage' $item.name
        Write-Host "Downloading $($item.name) from $($item.url)"
        Invoke-WebRequest -Uri $item.url -OutFile $dst -UseBasicParsing

        $actual   = Get-FileSha256 -Path $dst
        $expected = $item.sha256.ToUpperInvariant()
        if ($actual -ne $expected) { throw "Hash mismatch for $($item.name). expected=$expected actual=$actual" }

        if ($item.authenticode -eq $true) {
            $sig = Get-AuthenticodeSignature -FilePath $dst
            if ($sig.Status -ne 'Valid') { throw "Authenticode signature invalid for $($item.name): $($sig.Status)" }
        }

        if ($item.name -ieq 'LGPO.exe') {
            Copy-Item -LiteralPath $dst -Destination 'C:\Stage\lgpo\LGPO.exe' -Force
        }
    }

    # Optional silent installs if staged
    $ndp = 'C:\Stage\NDP481-Web.exe'
    if (Test-Path -LiteralPath $ndp) {
        Write-Host 'Installing .NET 4.8.1'
        $p = Start-Process -FilePath $ndp -ArgumentList '/passive /norestart' -Wait -PassThru
        if ($p.ExitCode -ne 0) { throw ".NET 4.8.1 installer returned $($p.ExitCode)" }
    }

    $vc = 'C:\Stage\vc_redist.x64.exe'
    if (Test-Path -LiteralPath $vc) {
        Write-Host 'Installing VC++ Redistributable x64'
        $p = Start-Process -FilePath $vc -ArgumentList '/quiet /norestart' -Wait -PassThru
        if ($p.ExitCode -ne 0) { throw "VC++ Redistributable installer returned $($p.ExitCode)" }
    }

    Write-Host ('Prestage complete. Items processed: {0}' -f $manifest.Count)
}
finally {
    Stop-Transcript | Out-Null
}
