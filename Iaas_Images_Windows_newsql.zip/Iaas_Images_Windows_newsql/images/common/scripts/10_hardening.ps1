# img-10_hardening.ps1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Start-Transcript -Path 'C:\Windows\Temp\img-10_hardening.log' -Append
try {
    # Import LGPO baseline from C:\Stage\lgpo (place LGPO.exe and policy export there)
    $lgpoExe = 'C:\Stage\lgpo\LGPO.exe'
    if (Test-Path -LiteralPath $lgpoExe) {
        Start-Process -FilePath $lgpoExe -ArgumentList '/g C:\Stage\lgpo' -Wait -NoNewWindow
    } else {
        Write-Warning 'LGPO.exe not found at C:\Stage\lgpo\LGPO.exe - skipping LGPO import'
    }

    function Ensure-RegistryValue {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory)][string]$Path,
            [Parameter(Mandatory)][string]$Name,
            [Parameter(Mandatory)]
            [ValidateSet('DWord','QWord','String','ExpandString','Binary','MultiString')]
            [string]$Type,
            [Parameter(Mandatory)][object]$Value
        )

        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Key -Force | Out-Null
        }

        $current = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name

        switch ($Type) {
            'DWord' { if ($Value -isnot [int])  { $Value = [int]$Value } }
            'QWord' { if ($Value -isnot [long]) { $Value = [long]$Value } }
            default { }
        }

        if ($null -eq $current -or $current -ne $Value) {
            New-ItemProperty -Path $Path -Name $Name -PropertyType $Type -Value $Value -Force | Out-Null
        }
    }

    # SCHANNEL: disable TLS 1.0/1.1, enable 1.2
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server'  -Name Enabled -Type DWord -Value 0
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client'  -Name Enabled -Type DWord -Value 0
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server'  -Name Enabled -Type DWord -Value 0
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client'  -Name Enabled -Type DWord -Value 0
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'  -Name Enabled -Type DWord -Value 1
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'  -Name Enabled -Type DWord -Value 1

    # Disable-by-default for old; keep TLS 1.2 enabled-by-default
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server'  -Name DisabledByDefault -Type DWord -Value 1
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client'  -Name DisabledByDefault -Type DWord -Value 1
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server'  -Name DisabledByDefault -Type DWord -Value 1
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client'  -Name DisabledByDefault -Type DWord -Value 1
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'  -Name DisabledByDefault -Type DWord -Value 0
    Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'  -Name DisabledByDefault -Type DWord -Value 0

    # Quick verification
    $checks = @(
        @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server';  Name='Enabled';           Expect=1 },
        @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client';  Name='Enabled';           Expect=1 },
        @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server';  Name='DisabledByDefault'; Expect=1 },
        @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client';  Name='DisabledByDefault'; Expect=1 }
    )
    $fail = $false
    foreach ($c in $checks) {
        $val = (Get-ItemProperty -Path $c.Path -ErrorAction SilentlyContinue).($c.Name)
        if ($val -ne $c.Expect) {
            Write-Error ("Hardening verification failed at {0}::{1} expected {2} got {3}" -f $c.Path, $c.Name, $c.Expect, $val)
            $fail = $true
        }
    }
    if ($fail) { throw 'Hardening verification failed.' }
}
finally {
    Stop-Transcript | Out-Null
}
