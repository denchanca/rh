# Molina RHEL 9 Azure Gold Image – Turnkey Packer Bundle

This bundle builds **Molina’s RHEL 9 gold image** for Azure using **HashiCorp Packer (HCL2)**. It supports **Gen1** and **Gen2** managed images, preserves Molina’s agent install flow (e.g., **Tanium**, **CrowdStrike**), includes a **provider-based prestage loop** for binaries, and offers an **optional Azure Key Vault (AKV)** certificate retrieval step.

---

## Contents

```
.
├── main.pkr.hcl                   # Main template (builders, provisioners)
├── variables.pkr.hcl              # All variables and feature flags
├── versions.pkr.hcl               # Packer + Azure plugin constraints
├── auto.pkrvars.hcl.example       # Example values; copy to auto.pkrvars.hcl
├── files/
│   └── providers.d/
│       └── azure/                 # Put Azure-specific installers here
│           └── README.txt
└── scripts/
    ├── prestage_providers.sh      # Prestage per-provider binaries
    ├── install_agents.sh          # Install Tanium, CrowdStrike, etc. (placeholders)
    ├── pull_akv_cert.sh           # Optional AKV secret/cert retrieval
    └── cleanup_and_deprovision.sh # Clean & waagent -deprovision
```

---

## Prerequisites

- **Azure subscription** + permissions to create VMs and **Managed Images** in the target RG
- **Packer ≥ 1.9** installed on your workstation or build agent
- **Azure CLI** (for CLI auth and/or AKV script)
- **SSH key** for Linux VM communicator (private key path passed via variables)
- Optional: **Service Principal** (if not using Azure CLI auth)

> **Auth Options**
> - **Azure CLI auth**: `use_azure_cli_auth = true` and `az login` before building.
> - **Service Principal**: set `subscription_id`, `tenant_id`, `client_id`, `client_secret` in vars.

---

## Quick Start (Local)
wget -O- https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo | sudo tee /etc/yum.repos.d/hashicorp.repo
**Verify with:**
dnf repolist | grep hashicorp
**Install with:**
dnf install packer

1) Copy example vars and edit:
```bash
cp auto.pkrvars.hcl.example auto.pkrvars.hcl
# Edit values inside (RG, image name, ssh key path, Gen1/Gen2 flag, etc.)
```
# Create the folder (if needed) and lock perms
sudo mkdir -p /home/packer/.ssh
sudo chown -R "$(whoami)":"$(whoami)" /home/packer /home/packer/.ssh
chmod 700 /home/packer/.ssh

# Generate RSA 4096 in legacy PEM format for max compatibility
ssh-keygen -t rsa -b 4096 -m PEM -N '' \
  -C "ado-agent $(date -u +%F)" \
  -f /home/packer/.ssh/id_rsa

# Derive the public key (if ssh-keygen didn’t already write it)
ssh-keygen -y -f /home/packer/.ssh/id_rsa > /home/packer/.ssh/id_rsa.pub

# Tighten perms
chmod 600 /home/packer/.ssh/id_rsa
chmod 644 /home/packer/.ssh/id_rsa.pub
2) Login to Azure (if using CLI auth):
```bash
az login
az account set -s "<SUBSCRIPTION_ID>"
```

3) Initialize and build:
```bash
packer init .
packer validate .
packer build .
```

> **Select Generation**: Set `azure_generation = "Gen2"` or `"Gen1"` in `auto.pkrvars.hcl`.
> **Managed Image Output**: Image is created in RG `managed_image_resource_group_name` with name `managed_image_name`.

---

## Provider Prestage Loop (binaries & agents)

Place cloud/provider-specific installers under:
```
files/providers.d/azure/
files/providers.d/aws/      # (future use)
```
During build, `prestage_providers.sh` copies the folder matching the provider into `/opt/molina/providers/<provider>/` on the VM. Example locations (for your own RPMs):

```
files/providers.d/azure/tanium/TaniumClient-<ver>.rpm
files/providers.d/azure/crowdstrike/falcon-sensor-<ver>.rpm
```

Your `install_agents.sh` can reference those paths.

---

## Agents Install (placeholders)

`scripts/install_agents.sh` includes **placeholders** for **Tanium** and **CrowdStrike**. Insert the real commands, for example:

```bash
# Tanium
sudo rpm -ivh /opt/molina/providers/azure/tanium/TaniumClient-*.rpm
sudo /opt/Tanium/TaniumClient/TaniumClient config set ServerNameList tanium.molina.local
sudo systemctl enable --now taniumclient

# CrowdStrike
sudo rpm -ivh /opt/molina/providers/azure/crowdstrike/falcon-sensor-*.rpm
sudo /opt/CrowdStrike/falconctl -s --cid=<CUSTOMER_ID>
sudo systemctl enable --now falcon-sensor
```

> **Tip**: Inject secrets like CrowdStrike CID via pipeline variables or Key Vault, not hard-coded.

---

## Optional: AKV Certificate Retrieval

- Toggle on by setting `enable_akv_cert = true` and set `akv_name`, `akv_secret_name`, `akv_out_path`.
- Script installs Azure CLI (if needed), downloads the secret, writes to `akv_out_path`, and updates trust if placed under `/etc/pki/ca-trust/source/anchors/`.

> **Permissions**: Ensure the identity used by Packer (CLI user or SPN) has **get** permission on the Key Vault secret. Consider using a **User-Assigned Managed Identity** for the build VM and `az login --identity` if preferred.

---

## Azure DevOps (YAML) – Example

```yaml
trigger: none
pool:
  vmImage: ubuntu-latest

variables:
  SUBSCRIPTION_ID: '$(AZ_SUBSCRIPTION_ID)'
  TENANT_ID: '$(AZ_TENANT_ID)'
  CLIENT_ID: '$(AZ_CLIENT_ID)'
  CLIENT_SECRET: '$(AZ_CLIENT_SECRET)' # secret
  IMAGE_RG: 'rg-gold-images'
  IMAGE_NAME: 'rhel9-gold-Gen2-$(Date:yyyyMMdd)'

steps:
- bash: |
    curl -L https://releases.hashicorp.com/packer/ | head -n1 >/dev/null
    packer version || true
    packer init .
    packer build       -var subscription_id=$(SUBSCRIPTION_ID)       -var tenant_id=$(TENANT_ID)       -var client_id=$(CLIENT_ID)       -var client_secret=$(CLIENT_SECRET)       -var managed_image_resource_group_name=$(IMAGE_RG)       -var managed_image_name=$(IMAGE_NAME)       -var admin_username="packer"       -var ssh_private_key_file="$(Agent.TempDirectory)/id_rsa"       -var azure_generation="Gen2"       .
  displayName: "Packer Build"
```

> **Secure Files**: Add a step to download an SSH private key to `$(Agent.TempDirectory)/id_rsa` before the build, or pull it from Key Vault.

---

## Layered App Installs

Use this gold image as a base for app-specific images:
- **Option 1**: Add more provisioners (scripts) here, guarded by flags.
- **Option 2** *(recommended)*: Create a second Packer template that uses this **managed image as the source** (`custom_managed_image_name`/`_resource_group_name`), then install app layers, and output a new managed image.

This keeps the base image small and consistent while allowing app teams to extend it cleanly.

---

## Troubleshooting

- **Env interpolation errors**: HCL2 does **not** support `{{env "FOO"}}` in fields. Use variables and pass values with `-var` or `auto.pkrvars.hcl`.
- **Image name exists**: Managed images **cannot be overwritten**. Use a unique `managed_image_name` each run or delete the old image.
- **Gen mismatch**: If `Gen2` fails to boot, verify the **SKU** is UEFI-capable (we default to `9-lvm-gen2`). Switch to `Gen1` if needed.
- **Agent installs**: Ensure installer files exist in `files/providers.d/azure/...` and script paths match.

---

## Verify Output

After success, check Azure for the managed image:
```bash
az image show -g <managed_image_resource_group_name> -n <managed_image_name> --query "[name,location,provisioningState]"
```

Launch a VM from the image and validate:
- Agents are present and running
- Certificates (if enabled) are installed
- OS updates applied
- VM boots correctly on target generation

---

## License / Notes

© Molina. This bundle is provided for internal use. Update scripts with actual installer commands and secure handling for credentials.


---

## Optional: Automated Azure Compute Gallery (SIG) Check‑in

Set `enable_sig_publish = true` to have the build **automatically publish** the managed image into an **Azure Compute Gallery** (a.k.a. SIG) after Packer finishes capturing the image. This runs as a **shell-local post‑processor** using Azure CLI on the machine running Packer.

**Required variables when enabled:**
- `sig_resource_group` – RG containing the gallery
- `sig_gallery_name` – Gallery name
- `sig_image_definition` – Image definition to create/use (e.g., `rhel9-gold`)
- `sig_version` – Version label (e.g., `1.0.0` or a date stamp like `2025.09.17`)
- `sig_replication_regions` – List of regions to replicate to (e.g., `["eastus","centralus"]`)

**What it does:**
1. Ensures you’re logged in with Azure CLI (use the same identity as the build).
2. Creates the **image definition** if it doesn’t exist.
3. Creates the **image version**, pointing at the freshly created **managed image**.
4. Replicates it to the regions you specified.

> You can still keep the managed image for local testing while distributing via SIG for scale/versioning.


---
# v4 Turnkey Addendum

**What's new in v4:**  
- Added **azure-pipelines.yml** (ADO) with Validate → Build → Optional SIG Check‑in → Publish
- Added **HOWTO.md** with step‑by‑step usage
- Added **manifest/** (CSV & YAML examples) + **scripts/30_manifest_apply.sh**
- Added **scripts/40_sig_checkin.sh** to publish to Shared Image Gallery
- Ensured provider pre‑stage loop supports vendors like Tanium and CrowdStrike
- Hardened AKV cert pull usage notes and service reload trigger
- Standardized output directory `_out/` for logs and artifacts
