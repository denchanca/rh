# Molina RHEL9 Gold Image – HOW‑TO (Turnkey v4)

_Last updated: 2025-09-17 19:04:00 _

This HOW‑TO walks you through building a hardened RHEL 9 image with optional agent pre‑staging, catalog/binary seeding, and **automatic Azure Shared Image Gallery (SIG) check‑in**. It also includes an **Azure DevOps pipeline (azure-pipelines.yml)** so you can run this end‑to‑end in ADO with approvals and variables.

---

## 1) Prereqs (local or build agent)

- Packer ≥ 1.11 (HCL2)
- Azure CLI ≥ 2.60 with `az account set` and RBAC to your image resource group & SIG
- Permissions to read secrets in Azure Key Vault when using `pull_akv_cert.sh`
- Optional: RHEL subscription or RHUI setup in your base image

> If building in Azure DevOps, the pipeline handles `az login` via a Service Connection.

## 2) Quickstart
```bash
cd molina_rhel9_turnkey
# Copy and edit the example vars
cp auto.pkrvars.hcl.example auto.pkrvars.hcl

# Dry run validate
packer init .
packer validate -var-file=auto.pkrvars.hcl .

# Build
packer build -var-file=auto.pkrvars.hcl .
```

## 3) Optional Features

### a) Provider loop pre‑stage (binaries & agents)
- Place vendor agents or tools under `providers.d/` (e.g., `providers.d/tanium/agent.rpm`, `providers.d/crowdstrike/falcon.rpm`).
- Use `scripts/prestage_providers.sh` or drive via the **manifest** (see below).

### b) Manifest‑driven installs (CSV/YAML)
- Put your manifests in `manifest/` (see `manifest/clients.csv`, `manifest/binaries.csv`, and YAML examples).
- The script `scripts/30_manifest_apply.sh` will iterate these and install/seed accordingly.
- CSV columns supported:
  - For clients: `name,package,install_cmd,enable,post_cmd`
  - For binaries: `name,source_path,dest_path,mode`

> YAML is also supported (simple list of maps). If `yq` is not present, the script falls back to a lightweight parser for basic key: value pairs.

### c) Auto SIG check‑in
Set `var.auto_sig_checkin=true` and provide SIG settings to publish the managed image as a new **SIG image version** right after build. You can also run it stand‑alone:
```bash
scripts/40_sig_checkin.sh \
  --resource-group $RG \
  --managed-image $IMG \
  --sig-name $SIG_NAME \
  --sig-image-def $SIG_DEF \
  --sig-version 1.0.0
```

### d) Key Vault certificate pull
Use `scripts/pull_akv_cert.sh` to retrieve a PEM or cert blob and place it at a secure path; if changed, optional service reload is triggered.

## 4) Azure DevOps (ADO) Pipeline

This repo includes `azure-pipelines.yml` with:
- Variables section (override in ADO Library)
- Stages: **Validate → Build → SIG Checkin (optional) → Publish Artifacts**
- Gated with environment approvals if you choose
- Uses an Azure Resource Manager service connection named **`AZURE_RM_SC`** by default

> Update the variables to match your subscription, resource group, SIG, and image definition names.

## 5) Outputs & Artifacts
- Packer manifest and build logs under `_out/`
- (Optional) SIG image version created when `auto_sig_checkin` is true
- ADO publishes logs and the built variable file for traceability

## 6) Troubleshooting
- **HCL errors**: run `packer fmt . && packer validate -var-file=auto.pkrvars.hcl .`
- **Azure auth**: confirm the ADO service connection or `az account show` locally
- **SIG check‑in**: ensure the SIG image definition exists and your identity has `Contributor` on the SIG RG.

## 7) File Map (key files)
- `main.pkr.hcl` – builders/provisioners
- `variables.pkr.hcl` – inputs including `auto_sig_checkin`
- `scripts/XX_*.sh` – lifecycle hooks
- `scripts/30_manifest_apply.sh` – applies `manifest/*.csv|yaml`
- `scripts/40_sig_checkin.sh` – SIG publisher
- `azure-pipelines.yml` – ADO pipeline (CI/CD)

---

**Security note:** These scripts assume least‑privilege RBAC and do not hardcode secrets. Use Key Vault and ADO variable groups for secrets.
