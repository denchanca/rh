#!/usr/bin/env bash
set -euo pipefail

ENABLE="${ENABLE_AKV_CERT:-${ENABLE_AKV_CERT_ENV:-}}"

echo "[debug] Environment dump:"
env | grep AKV || echo "[debug] No AKV-related env vars found"

echo "[debug] ENABLE=${ENABLE}"


# Exit early if not enabled. Packer can't easily 'if' provisioners, so we self-skip.
if [[ "${ENABLE:-false}" != "true" ]]; then
  echo "[akv] ENABLE_AKV_CERT not true; skipping AKV cert retrieval."
  exit 0
fi

AKV_NAME="${AKV_NAME:-}"
AKV_SECRET_NAME="${AKV_SECRET_NAME:-}"
AKV_OUT_PATH="${AKV_OUT_PATH:-/etc/pki/ca-trust/source/anchors/molina-ca.crt}"

if [[ -z "$AKV_NAME" || -z "$AKV_SECRET_NAME" ]]; then
  echo "[akv] AKV_NAME or AKV_SECRET_NAME not set; skipping."
  exit 0
fi

echo "[akv] Installing Azure CLI if needed..."
if ! command -v az >/dev/null 2>&1; then
  sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
  sudo dnf -y install dnf-plugins-core || sudo yum -y install dnf-plugins-core || true
  sudo dnf config-manager --add-repo https://packages.microsoft.com/yumrepos/azure-cli || true
  sudo dnf install -y python3-cffi || sudo yum install -y python3-cffi || true
  sudo dnf -y install azure-cli || sudo yum -y install azure-cli
fi

echo "[akv] Attempting to use Azure CLI context (SPN or CLI login should already be available)."
# Download secret as a file (assumes secret contains PEM or CRT content)
TMP="/tmp/molina-akv-secret"
az login --service-principal --username "$ARM_CLIENT_ID" --password "$ARM_CLIENT_SECRET" --tenant "$ARM_TENANT_ID"
az keyvault secret download --vault-name "$AKV_NAME" --name "$AKV_SECRET_NAME" -f "$TMP"

sudo mkdir -p "$(dirname "$AKV_OUT_PATH")"
sudo cp "$TMP" "$AKV_OUT_PATH"
sudo chmod 0644 "$AKV_OUT_PATH"
rm -f "$TMP"

# If it's a CA cert, update trust
if [[ "$AKV_OUT_PATH" == *"/anchors/"* ]]; then
  if command -v update-ca-trust >/dev/null 2>&1; then
    sudo update-ca-trust
  elif command -v update-ca-certificates >/dev/null 2>&1; then
    sudo update-ca-certificates
  fi
fi

echo "[akv] AKV secret retrieved to $AKV_OUT_PATH"
