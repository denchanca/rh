#!/usr/bin/env bash
set -euo pipefail

echo "[cleanup] Removing temporary files and logs..."
sudo rm -rf /tmp/files || true
sudo rm -rf /tmp/scripts || true
sudo rm -rf /var/log/* || true

echo "[cleanup] Truncating machine-id..."
sudo truncate -s 0 /etc/machine-id || true

echo "[cleanup] Azure Linux agent deprovision..."
if command -v waagent >/dev/null 2>&1; then
  sudo waagent -force -deprovision+user || true
fi

echo "[cleanup] Sync disks and power off (Packer will capture image)..."
sync
sudo systemctl poweroff --no-block || sudo shutdown -h now || true
