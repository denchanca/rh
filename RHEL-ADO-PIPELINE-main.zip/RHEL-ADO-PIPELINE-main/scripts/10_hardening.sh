#!/usr/bin/env bash
set -euo pipefail
setenforce 1 || true
sed -i 's/^SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config
systemctl enable --now firewalld || true
update-crypto-policies --set DEFAULT
chown root:root /var/log
chmod 0755 /var/log
echo 'kernel.randomize_va_space=2' > /etc/sysctl.d/99-hardening.conf
sysctl --system
