#!/usr/bin/env bash
set -euo pipefail

PROVIDER="${PROVIDER_NAME:-${PACKER_BUILDER_TYPE:-azure-arm}}"

# Normalize builder type to provider path
case "$PROVIDER" in
  azure-arm|azure) PROVIDER_DIR="azure" ;;
  amazon-ebs|aws)  PROVIDER_DIR="aws" ;;
  *)               PROVIDER_DIR="${PROVIDER_NAME:-azure}" ;;
esac

SRC_DIR="/tmp/files/providers.d/${PROVIDER_DIR}"
DST_DIR="/opt/molina/providers/${PROVIDER_DIR}"

echo "[prestage] Provider: ${PROVIDER_DIR}"
if [[ -d "$SRC_DIR" ]]; then
  sudo mkdir -p "$DST_DIR"
  sudo cp -a "$SRC_DIR/." "$DST_DIR/" || true
  sudo find "$DST_DIR" -type f -name "*.sh" -exec chmod +x {} \;
  echo "[prestage] Copied provider assets to $DST_DIR"
else
  echo "[prestage] No provider assets found at $SRC_DIR (skipping)"
fi
