#!/usr/bin/env bash
set -euo pipefail
dnf -y update
dnf -y install jq curl unzip ca-certificates openssl policycoreutils-python-utils rsyslog audit audit-libs openscap-scanner scap-security-guide
systemctl enable --now rsyslog
systemctl enable --now auditd
sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl restart sshd
