#!/usr/bin/env bash
set -euo pipefail
CATALOG="${1:-/tmp/scripts/catalog.json}"
TARGET="/opt/stage/Tools"
need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing $1"; exit 1; }; }
need jq; need curl; need sha256sum
mkdir -p "$TARGET"
ALLOWLIST="checkmk appdynamics crowdstrike tanium splunkuf"
jq -r '.images[] | @base64' "$CATALOG" | while read -r row; do
  _jq(){ echo "$row" | base64 -d | jq -r "$1"; }
  id=$(_jq '.id'); ver=$(_jq '.version'); url=$(_jq '.artifact'); sha=$(_jq '.sha256'); stage=$(_jq '.stage // true')
  echo "$ALLOWLIST" | tr ' ' '\n' | grep -qx "$id" || { echo "Skip non-allowlisted id=$id"; continue; }
  [ "$stage" = "true" ] || { echo "Skip stage=false id=$id"; continue; }
  [ -n "$sha" ] && [ "$sha" != "<REPLACE_WITH_SHA256>" ] || { echo "Missing SHA for $id; fail"; exit 2; }
  echo "$url" | grep -q '^https://' || { echo "Non-HTTPS URL for $id; fail"; exit 2; }
  dest_dir="$TARGET/$id/$ver"; mkdir -p "$dest_dir"; file="$dest_dir/$(basename "$url")"
  if [ ! -f "$file" ]; then curl -fsSL "$url" -o "$file"; else echo "Already present $file"; fi
  echo "$sha  $file" | sha256sum -c - || { echo "Hash mismatch for $file"; exit 3; }
done
chmod -R 0755 /opt/stage || true
