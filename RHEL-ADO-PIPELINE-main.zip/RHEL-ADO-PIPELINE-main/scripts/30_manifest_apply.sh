#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MANIFEST_DIR="${ROOT}/manifest"

log(){ echo "[manifest] $*"; }

apply_clients_csv(){
  local csv="${MANIFEST_DIR}/clients.csv"
  [[ -f "$csv" ]] || return 0

  tail -n +2 "$csv" | while IFS=',' read -r name package install_cmd enable post_cmd; do
    [[ -z "${name:-}" ]] && continue
    log "Installing client: $name"
    if [[ -n "${install_cmd:-}" ]]; then
      bash -lc "$install_cmd"
    elif [[ -n "${package:-}" ]]; then
      yum install -y "$package"
    fi
    if [[ "${enable:-}" == "true" ]]; then
      systemctl enable --now "${name}" || true
    fi
    if [[ -n "${post_cmd:-}" && "${post_cmd}" != " " ]]; then
      bash -lc "$post_cmd" || true
    fi
  done
}

apply_binaries_csv(){
  local csv="${MANIFEST_DIR}/binaries.csv"
  [[ -f "$csv" ]] || return 0

  tail -n +2 "$csv" | while IFS=',' read -r name source_path dest_path mode; do
    [[ -z "${name:-}" ]] && continue
    [[ -z "${source_path:-}" ]] && continue
    [[ -z "${dest_path:-}" ]] && continue
    log "Staging binary: $name from $source_path to $dest_path"
    install -Dm "${mode:-0755}" "$ROOT/${source_path#./}" "$dest_path"
  done
}

# Minimal YAML support without yq (expects simple top-level list under 'clients:' or 'binaries:')
parse_simple_yaml_list(){
  # usage: parse_simple_yaml_list <yaml_path> <key>
  local yfile="$1"; shift
  local key="$1"; shift

  awk -v target="$key" '
  $0 ~ "^[[:space:]]*"target":" {inlist=1; next}
  inlist && $0 ~ "^[[:space:]]*-[[:space:]]" { if (obj!="") print obj; obj=""; next}
  inlist && $0 ~ "^[[:space:]]*[a-zA-Z0-9_]+:" {
    gsub(/^[[:space:]]*/,"",$0); 
    split($0, a, ":");
    k=a[1]; sub(/^[[:space:]]*:[[:space:]]*/,"",$0);
    v=$0; gsub(/^"[ ]*|[ ]*"$/,"",v);
    if (obj!="") obj=obj" "; 
    obj=obj k"="v
  }
  END { if (obj!="") print obj }
  ' "$yfile"
}

apply_clients_yaml(){
  local y="${MANIFEST_DIR}/clients.yaml"
  [[ -f "$y" ]] || return 0
  while IFS= read -r line; do
    # line like: name=tanium install_cmd="yum install..." enable=true post_cmd="..."
    eval "$line"
    [[ -z "${name:-}" ]] && continue
    log "Installing client (yaml): $name"
    if [[ -n "${install_cmd:-}" ]]; then
      bash -lc "$install_cmd"
    fi
    if [[ "${enable:-}" == "true" ]]; then
      systemctl enable --now "${name}" || true
    fi
    if [[ -n "${post_cmd:-}" ]]; then
      bash -lc "$post_cmd" || true
    fi
  done < <(parse_simple_yaml_list "$y" clients)
}

apply_binaries_yaml(){
  local y="${MANIFEST_DIR}/binaries.yaml"
  [[ -f "$y" ]] || return 0
  while IFS= read -r line; do
    eval "$line"
    [[ -z "${name:-}" ]] && continue
    [[ -z "${source_path:-}" || -z "${dest_path:-}" ]] && continue
    log "Staging binary (yaml): $name"
    install -Dm "${mode:-0755}" "$ROOT/${source_path#./}" "$dest_path"
  done < <(parse_simple_yaml_list "$y" binaries)
}

main(){
  log "Applying manifest in $MANIFEST_DIR"
  apply_clients_csv
  apply_binaries_csv
  apply_clients_yaml
  apply_binaries_yaml
  log "Done."
}

main "$@"
