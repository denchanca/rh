[cmdletbinding()]
param(
	[Parameter(Mandatory = $True)]
	[string]$saPwd
)

#Get script path
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Set to default instance
$InstanceName = "MSSQLSERVER"

##Handling internal variables
#Getting the version based on the config file name
$ConfigTemplateName = Get-ChildItem -Path $ScriptPath -Name *_DefaultInstTemplate.ini

#Set SQLCMD instance name
$CmdInstance = "localhost"

$HostName = [System.Net.Dns]::GetHostName()

$TempDir = "C:\Temp"
$InstallConfigFile = $TempDir + "\" + $InstanceName + "_Config.ini"

#Load config file template into memory
[string]$ConfigTemplate = [System.IO.File]::ReadAllText("$ScriptPath\$ConfigTemplateName")

#Get current user's Windows/AD account
$WinSysadminAccount = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
if (([string]::IsNullOrEmpty($WinSysadminAccount)) -or ($WinSysadminAccount -eq "The command completed successfully." )) {
	# Use admin account as a fallback in case user account can't be retrieved
	$HasWinSysadminAccount = "N"
	$WinSysadminAccount = "Administrator"
} else {
	$HasWinSysadminAccount = "Y"
}

#Create temp directory if it doesn't exist
if (!(Test-Path C:\Temp)) {
	New-Item -ItemType Directory -Force -Path C:\Temp | Out-Null
}

#Prepare config file
[string]$ConfigFile = $ConfigTemplate

$ConfigFile | Out-File -Encoding ASCII -FilePath $InstallConfigFile -Force

Write-Host " Starting SQL Server installation for instance $InstanceName..."
Start-Process -NoNewWindow -Wait -FilePath "$ScriptPath\Setup.exe" -ArgumentList "/SAPWD=$saPwd /Q /Action=install /IACCEPTSQLSERVERLICENSETERMS /SQLSYSADMINACCOUNTS=$WinSysadminAccount /ConfigurationFile=$InstallConfigFile"
#Check if install finished and service is running
$ServiceName = Get-Service -Name "SQL Server ($InstanceName)" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" } | Select-Object -ExpandProperty DisplayName
if ($null -eq $ServiceName) {
	while ($null -eq $ServiceName) {
		Start-Sleep -Seconds 35
		$ServiceName = Get-Service -Name "SQL Server ($InstanceName)" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" } | Select-Object -ExpandProperty DisplayName
	}
}
#Wait 5 seconds for the system databases to be initialized
Start-Sleep -Seconds 5
Write-Host " Instance installation finished." -Fore Green
Write-Host " Proceeding with post-install configuration steps..."

#SQL Server CTP and model db tweaks
$InstanceConfigTweaks = @"
EXEC sys.sp_configure N'show advanced options', N'1';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'cost threshold for parallelism', N'50';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'backup compression default', N'1';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'show advanced options', N'0';
GO
RECONFIGURE WITH OVERRIDE;
GO
ALTER DATABASE [model] SET RECOVERY SIMPLE WITH NO_WAIT;
GO
ALTER DATABASE [model] MODIFY FILE (NAME = N'modeldev', FILEGROWTH = 400MB);
GO
ALTER DATABASE [model] MODIFY FILE (NAME = N'modellog', FILEGROWTH = 300MB);
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'BUILTIN\Administrators')
BEGIN
    CREATE LOGIN [BUILTIN\Administrators] FROM WINDOWS;
    EXEC sys.sp_addsrvrolemember @loginame = N'BUILTIN\Administrators', @rolename = N'sysadmin';
END
CREATE LOGIN [MMC\SQLAdministrators] FROM WINDOWS;
EXEC sys.sp_addsrvrolemember @loginame = N'MMC\SQLAdministrators', @rolename = N'sysadmin';
GO
CREATE LOGIN [MMC\SQLAdmin_Projects] FROM WINDOWS;
EXEC sys.sp_addsrvrolemember @loginame = N'MMC\SQLAdmin_Projects', @rolename = N'sysadmin';
GO
CREATE LOGIN [MMC\DBA_Support_Infosys] FROM WINDOWS;
EXEC sys.sp_addsrvrolemember @loginame = N'MMC\DBA_Support_Infosys', @rolename = N'sysadmin';
GO
"@

#If local Admin account was added as a workaround for the install error, drop it here
if ($HasWinSysadminAccount -eq "N") {
	$InstanceConfigTweaks = $InstanceConfigTweaks + @"
DECLARE @SQL NVARCHAR(300);
DECLARE @WinSysAdminLogin NVARCHAR(128);
SELECT @WinSysAdminLogin = [name] FROM sys.server_principals
WHERE [name] LIKE N'%Administrator';
SET @SQL = N'DROP LOGIN ['+ @WinSysAdminLogin +N'];'
EXEC(@SQL);
GO
"@
}

#Refresh path environment variable so we can use sqlcmd
$Env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine")

$TestQuery = "SET NOCOUNT ON;`nSELECT 'XYZ';`nGO"
#Waiting for the instance to get out of single user mode
[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $TestQuery -x 2>&1 | Out-String
#cleanup output noise
$sqlcmdOut = $sqlcmdOut -replace " ", ""
$sqlcmdOut = $sqlcmdOut -replace "-", ""
$sqlcmdOut = $sqlcmdOut -replace "`r`n", ""
while ($sqlcmdOut -ne "XYZ") {
	Write-Host " The instance is not connectable yet - waiting 20 seconds..."
	Start-Sleep -Seconds 20
	[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $TestQuery -x 2>&1 | Out-String
	$sqlcmdOut = $sqlcmdOut -replace " ", ""
	$sqlcmdOut = $sqlcmdOut -replace "-", ""
	$sqlcmdOut = $sqlcmdOut -replace "`r`n", ""
}

[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $InstanceConfigTweaks -x 2>&1 | Out-String
#Cleaning up the output
$sqlcmdOut = $sqlcmdOut -replace ". Run the RECONFIGURE statement to install" , ""
Write-Host $sqlcmdOut

Write-Host ("=" * 90)
Write-Host " SQL Server installation and configuration - " -NoNewline
Write-Host "Done" -Fore Green
Write-Host " Instance: " -NoNewline
Write-Host "$HostName"
Write-Host " sa password: $saPwd"
Write-Host " TCP port: 1433"
Write-Host " The local Administrators group has been added as a sysadmin on the instance."
Write-Host " The config .ini file used for the installation has been saved as:"
Write-Host " $InstallConfigFile"
Write-Host " "
Write-Host ("=" * 90)
Write-Host "The machine needs to be restarted to complete the installation."