# Install SQL Developer Edition
$sqlZipName = 'SQLServer_DEV_2022.zip'
$sqlExtractPath = 'C:\Stage'
$sqlZipPath = Join-Path 'C:\Stage' $sqlZipName

if (Test-Path $sqlZipPath) {
    Write-Host "Extracting SQL Server ZIP..."
    Expand-Archive -Path $sqlZipPath -DestinationPath $sqlExtractPath -Force
    Write-Host "SQL Server ZIP extracted to $sqlExtractPath"
# Define source file paths
$file1 = "C:\Windows\Temp\scripts\InstallSQLServer.ps1"
$file2 = "C:\Windows\Temp\scripts\Molina-ConfigurationFile.ini"

# Define destination folder
$destination = "C:\Stage\SQLServer_DEV_2022\"

# Copy the files to the destination
Copy-Item -Path $file1 -Destination $destination -Force
Copy-Item -Path $file2 -Destination $destination -Force

Write-Host "SQL Installation Config Files copied successfully."

$installScriptPath = Join-Path $destination 'InstallSQLServer.ps1'

if (Test-Path $installScriptPath) {

& $installScriptPath -saPwd SuperStr0ngPassword

Write-Host "SQL Server installation script completed."
} else {
    Write-Warning "InstallSQLServer.ps1 not found at $installScriptPath"
}

} else {
    Write-Warning "SQL ZIP not found at $sqlZipPath"
}