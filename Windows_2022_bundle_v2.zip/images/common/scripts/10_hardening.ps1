Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Start-Transcript -Path "C:\Windows\Temp\img-10_hardening.log" -Append

# Import LGPO baseline from C:\Stage\lgpo (place LGPO.exe and policy export there)
$lgpoExe = 'C:\Stage\lgpo\LGPO.exe'
if (Test-Path $lgpoExe) {
    Start-Process $lgpoExe -ArgumentList '/g C:\Stage\lgpo' -Wait
} else {
    Write-Warning "LGPO.exe not found at C:\Stage\lgpo\LGPO.exe — skipping LGPO import"
}

function Ensure-RegistryValue {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('DWord','QWord','String','ExpandString','Binary','MultiString')][string]$Type,
        [Parameter(Mandatory)][Object]$Value
    )
    if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
    $current = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name
    if ($null -eq $current -or $current -ne $Value) {
        New-ItemProperty -Path $Path -Name $Name -PropertyType $Type -Value $Value -Force | Out-Null
    }
}

# SCHANNEL hardening — disable TLS 1.0/1.1, enable TLS 1.2 (Server/Client)
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Name Enabled -Type DWord -Value 0
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Name Enabled -Type DWord -Value 0
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Name Enabled -Type DWord -Value 0
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Name Enabled -Type DWord -Value 0
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name Enabled -Type DWord -Value 1
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name Enabled -Type DWord -Value 1

# Optional: Disable by default older protocols
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Name DisabledByDefault -Type DWord -Value 1
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Name DisabledByDefault -Type DWord -Value 1
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Name DisabledByDefault -Type DWord -Value 1
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Name DisabledByDefault -Type DWord -Value 1
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name DisabledByDefault -Type DWord -Value 0
Ensure-RegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name DisabledByDefault -Type DWord -Value 0

# Confirm critical outcomes
$checks = @(
  @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'; Name='Enabled'; Expect=1},
  @{Path='HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'; Name='Enabled'; Expect=1}
)
$fail = $false
foreach ($c in $checks) {
    $val = (Get-ItemProperty -Path $c.Path -ErrorAction SilentlyContinue).($c.Name)
    if ($val -ne $c.Expect) {
        Write-Error "Hardening verification failed at $($c.Path)::$($c.Name) expected $($c.Expect) got $val"
        $fail = $true
    }
}
if ($fail) { throw "Hardening verification failed." }

Stop-Transcript
