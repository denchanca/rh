#!/usr/bin/env bash
set -euo pipefail

fail() { echo "POLICY-GUARD: $1" >&2; exit 1; }

# Block winrm_insecure true in packer templates
if grep -Riq '"winrm_insecure"\s*:\s*true' images 2>/dev/null; then
  fail "winrm_insecure=true found in templates"
fi

# Block hardcoded secrets in scripts (very basic heuristic)
if grep -RiqE 'SAS|AccountKey|SharedAccessSignature' images/common/scripts 2>/dev/null; then
  fail "Potential secret pattern found in scripts"
fi

# Ensure manifest.json referenced
if ! grep -Riq 'manifest.json' images/common/scripts/20_prestage.ps1 2>/dev/null; then
  fail "20_prestage.ps1 does not reference manifest.json"
fi

echo "POLICY-GUARD: All checks passed."
