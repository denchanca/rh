param(
  [Parameter(Mandatory)][string]$SourcePath,
  [string]$BaseUrl = "https://<your-artifacts>/"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-FileSha256([string]$Path) {
  return (Get-FileHash -Path $Path -Algorithm SHA256).Hash.ToUpper()
}

$items = Get-ChildItem -Path $SourcePath -File | ForEach-Object {
  [pscustomobject]@{
    name = $_.Name
    url  = ($BaseUrl.TrimEnd('/') + '/' + $_.Name)
    sha256 = Get-FileSha256 -Path $_.FullName
    authenticode = ($(Get-AuthenticodeSignature -FilePath $_.FullName).Status -eq 'Valid')
  }
}
$items | ConvertTo-Json -Depth 3 | Out-File -FilePath (Join-Path $SourcePath 'manifest.json') -Encoding utf8
Write-Host "Wrote manifest.json in $SourcePath"
