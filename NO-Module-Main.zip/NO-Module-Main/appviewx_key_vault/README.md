# AppViewX Certificate Provisioning with Azure Key Vault

This Terraform module automates the process of:

1. Creating an SSL/TLS certificate using AppViewX.
2. Creating an Azure Resource Group and Key Vault.
3. Uploading the generated certificate into Azure Key Vault.

## Components

- `appviewx_create_certificate`: Requests a certificate from AppViewX.
- `azurerm_resource_group`: Creates a resource group in Azure.
- `azurerm_key_vault`: Sets up a Key Vault with proper access policies and network rules.
- `azurerm_key_vault_certificate`: Uploads the certificate to Azure Key Vault using a PFX file.

## Azure Terraform Configuration
```bash
export ARM_CLIENT_ID="<YOUR_CLIENT_ID>"
export ARM_CLIENT_SECRET="<YOUR_CLIENT_SECRET>"
export ARM_SUBSCRIPTION_ID="<YOUR_SUBSCRIPTION_ID>"
export ARM_TENANT_ID="<YOUR_TENANT_ID>"
```

## AppViewX Terraform Configuration
```bash
export APPVIEWX_TERRAFORM_CLIENT_ID="your_client_id"
export APPVIEWX_TERRAFORM_CLIENT_SECRET="your_client_secret"
export APPVIEWX_TERRAFORM_USERNAME="your_username"
export APPVIEWX_TERRAFORM_PASSWORD="your_password"
```
## References

- https://registry.terraform.io/providers/AppViewX/appviewx/latest/docs
- https://registry.terraform.io/providers/AppViewX/appviewx/latest/docs/resources/appviewx_create_certificate
- https://registry.terraform.io/providers/AppViewX/appviewx/latest/docs/resources/appviewx_create_certificate_push_akv
- https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs
- https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault
- https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_certificate