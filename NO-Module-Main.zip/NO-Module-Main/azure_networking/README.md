# Azure Networking Infrastructure Deployment with Terraform

This Terraform configuration provisions a basic Azure networking infrastructure, including:

* A Resource Group
* Virtual Network (VNet) and Subnet
* Route Table and association
* Network Security Group (NSG) and association
* Public IP Address
* Network Interface (NIC)
* Private Endpoint and Private Link Service

## Resources Created

### 1. **Resource Group**

* Creates a centralized group to contain all Azure resources.

### 2. **Virtual Network (VNet)**

* Defined with address space and optional custom DNS servers.
* Optional DDoS Protection Plan (currently disabled).

### 3. **Subnet**

* Attached to the VNet.
* Configured for Private Link Service with appropriate policies.

### 4. **Route Table**

* Includes a default route to the Internet (`0.0.0.0/0`).
* Associated with the subnet.

### 5. **Network Security Group (NSG)**

* Includes an inbound rule to allow SSH (`TCP 22`) from the Internet.
* Associated with the subnet.

### 6. **Public IP Address**

* Static and Standard SKU IPv4 address.

### 7. **Network Interface (NIC)**

* Connected to the subnet.
* Configured with a dynamic private IP and associated with the public IP.

### 8. **Private Link Service**

* Allows Azure Private Endpoint connections.
* Uses NAT IP configuration with a specified static private IP.
* Routes the traffic to a destination IP. Can also route to an LoadBalancer Service.

### 9. **Private Endpoint**

* Connects securely to the Private Link Service.
* Attached to the same subnet.