# Azure AKS Deployment with Key Vault, Helm Charts, and CSI Secret Store

This Terraform configuration provisions an Azure Kubernetes Service (AKS) cluster with:

- Custom Virtual Network and Subnets
- System and User Node Pools
- Azure Key Vault for secret storage
- Prometheus & NGINX Ingress via Helm
- CSI Driver to mount secrets from Key Vault into pods

---

## Quickstart
Prerequisites:

* Azure CLI authenticated
* Existing Resource Group
* Update Nginx Ingress values in `nginx-values.yaml`

---

### 1. Initialize Terraform

```bash
terraform init
```

### 2. Create Only the AKS Cluster

This step creates:

* VNet and subnets
* AKS cluster with system node pool
* Identity configuration

```bash
terraform apply -target=azurerm_kubernetes_cluster.main
```

### 4. Create the Rest (Full Infra)

This will provision:

* Key Vault and Secret
* User Node Pool
* CSI Secret Store and Pod
* Prometheus Operator & NGINX Ingress (via Helm)

```bash
terraform apply
```

---

## Components

| Component                              | Description                                 |
| -------------------------------------- | ------------------------------------------- |
| `azurerm_kubernetes_cluster`           | Creates the main AKS cluster                |
| `azurerm_kubernetes_cluster_node_pool` | Adds a user-defined node pool               |
| `azurerm_key_vault`                    | Manages secrets with RBAC enabled           |
| `azurerm_key_vault_secret`             | Adds a sample secret                        |
| `azurerm_role_assignment`              | Grants required permissions                 |
| `helm_release`                         | Installs Prometheus Stack and NGINX Ingress |
| `kubernetes_manifest`                  | Defines SecretProviderClass for CSI         |
| `kubernetes_pod`                       | Sample nginx pod using mounted secret       |

---

## Secret Access Flow

1. A secret is stored in **Azure Key Vault**
2. AKS uses **CSI Driver** to fetch that secret
3. The `nginx` pod mounts the secret at `/mnt/secrets-store`

---

## 🛠 Variables

You must define variables such as:

* `aks_cluster_name`
* `location`
* `resource_group`
* `vnet_cidr`, `subnet_cidr`, `user_nodepool_subnet_cidr`
* `aad_admin_group_object_ids`
* `key_vault_name`
* `node_pool_name`, `node_count`, `min_count`, `max_count`
* `k8s_version`, `vm_size`
* `owner`, `environment`, `cost_center`, etc.

Use a `terraform.tfvars` file or pass via `-var` flags.

---

## Cleanup

To destroy all resources:

```bash
terraform destroy
```

---

## Notes

* `rbac_authorization_enabled` is used for secure access
* `nginx-values.yaml` is required for configuring the Helm chart
* `Network Contributor` role is needed for subnet management by AKS
* `SecretProviderClass` uses **system-assigned managed identity**

