# Turnkey Assets

This folder contains ready-to-use scripts, tests, and Ansible stubs to operationalize the Windows Server 2022 SQL golden images.

## Layout
- images/common/scripts
  - 00_prereq.ps1 — base OS prerequisites
  - 10_hardening.ps1 — LGPO + SCHANNEL hardening (idempotent)
  - 20_prestage.ps1 — manifest-driven downloads + SHA-256 verification; optional .NET/VC++ install
  - 99_sysprep.ps1 — generalize and exit checks
- images/common/artifacts
  - manifest.template.json — fill in URLs + SHA256 for each artifact
- scripts
  - New-ArtifactManifest.ps1 — compute a manifest.json from a local folder of binaries
- tests
  - Validate-ImageBaseline.Tests.ps1 — Pester tests for boot validation
- ansible
  - playbooks/postdeploy.yml — sample post-deploy play
  - roles/domain_join, agent_enroll, sql_config — stubs for environment-bound work

## Quick Start
1. Upload your binaries (SQL ISOs per edition, CU EXE, LGPO.exe, agent installers) to your artifact store.
2. Generate/complete `manifest.json` (use scripts/New-ArtifactManifest.ps1 or edit manifest.template.json and fill SHA256).
3. Ensure Packer templates point to these scripts and set `ARTIFACT_MANIFEST` env var to `C:\Stage\manifest.json`.
4. Run the ADO pipeline with parameter `edition=Enterprise|Standard|Developer`.
5. Boot-test the candidate image and run `tests/Validate-ImageBaseline.Tests.ps1`.
6. Publish to SIG on success and replicate to consuming regions.
7. Post-deploy: run the Ansible play to domain join, enroll agents (e.g., Tanium), configure SQL, and bind certificates via AKV.

## Notes
- Do NOT enroll agents in the image; only stage binaries.
- Keep secrets out of templates. Pull them from Azure Key Vault at runtime.
- Use WinRM over HTTPS with certificate validation; never set winrm_insecure=true.


## Additional Assets
- pipelines/azure-pipelines.yml — parameterized build pipeline
- pipelines/tools/policy-guard.sh — simple policy gate used in Validate stage
- iac/terraform/akv_windows_extension.tf — attach AKV VM extension via Terraform
- iac/bicep/akv_windows_extension.bicep — attach AKV VM extension via Bicep
- ansible/inventory/azure_rm.yml — dynamic inventory with licensing-safe filters
- ansible/group_vars/all.yml — example group variables
- scripts/Bind-SqlServerCertificate.ps1 — bind a certificate to SQL (uses LocalMachine\My thumbprint)
