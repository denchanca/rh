Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Start-Transcript -Path "C:\Windows\Temp\img-00_prereq.log" -Append

# OS prerequisites that are broadly useful (keep minimal to avoid bloat)
# .NET Framework feature (OS component) — safe baseline for most workloads
if (-not (Get-WindowsFeature -Name NET-Framework-Features).Installed) {
    Install-WindowsFeature -Name NET-Framework-Features -IncludeAllSubFeature -IncludeManagementTools | Out-Null
}

# NOTE: OS cumulative updates should be applied either by your update maintenance window
# or via your preferred servicing method during build. Keep build reboots minimal.

Stop-Transcript
