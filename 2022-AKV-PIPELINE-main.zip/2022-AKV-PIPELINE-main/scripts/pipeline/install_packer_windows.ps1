Param([string]$Version = "1.11.2")
$ErrorActionPreference = 'Stop'
$zip = "$env:Agent_TempDirectory\packer.zip"
$dst = "$env:Agent_TempDirectory\packer"
Invoke-WebRequest "https://releases.hashicorp.com/packer/$Version/packer_${Version}_windows_amd64.zip" -OutFile $zip
Expand-Archive -Path $zip -DestinationPath $dst -Force
Write-Host "Packer installed to $dst"
