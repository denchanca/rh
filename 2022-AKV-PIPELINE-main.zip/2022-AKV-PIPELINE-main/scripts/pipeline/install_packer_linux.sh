#!/usr/bin/env bash
set -euo pipefail
VER="${1:-1.11.2}"
DST="${AGENT_TEMPDIRECTORY:-/tmp}/packer"
mkdir -p "$DST"
curl -fsSL "https://releases.hashicorp.com/packer/${VER}/packer_${VER}_linux_amd64.zip" -o "$DST/packer.zip"
unzip -o "$DST/packer.zip" -d "$DST"
echo "Packer installed to $DST"
