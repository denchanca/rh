param(
  [Parameter(Mandatory=$true)][string]$Path,
  [string]$Sha256File = ""
)

Write-Host "Verifying $Path"

# 1) Authenticode (if PE, MSI, or signed PS1)
try {
  $sig = Get-AuthenticodeSignature -FilePath $Path -ErrorAction Stop
  if ($sig.Status -ne 'NotSigned') {
    if ($sig.Status -ne 'Valid') {
      throw "Authenticode signature invalid: $($sig.Status)"
    } else {
      Write-Host "Authenticode: Valid"
    }
  } else {
    Write-Host "Authenticode: NotSigned (skipping)"
  }
} catch {
  Write-Warning "Authenticode check error: $_"
}

# 2) SHA256 (optional file list or .sha256 file with 'hash  filename' format)
if ($Sha256File -and (Test-Path $Sha256File)) {
  $map = @{}
  Get-Content $Sha256File | ForEach-Object {
    if ($_ -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
      $map[$matches[2]] = $matches[1].ToLower()
    }
  }
  $name = Split-Path -Leaf $Path
  if ($map.ContainsKey($name)) {
    $actual = (Get-FileHash -Algorithm SHA256 -Path $Path).Hash.ToLower()
    if ($actual -ne $map[$name]) {
      throw "SHA256 mismatch for $name"
    } else {
      Write-Host "SHA256: Match"
    }
  } else {
    Write-Warning "No SHA256 entry for $name in $Sha256File"
  }
} else {
  Write-Host "SHA256: Skipped (no checksum file provided)"
}
