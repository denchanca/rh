# Placeholder installer for SQL Dev
$iso = 'installers/SQLServer/SQLServer2019-Dev.iso'
if (-not (Test-Path $iso)) { Write-Error "Missing $iso"; exit 1 }
Write-Host "Would mount $iso and run unattended install..."
