<#
.SYNOPSIS
  Binds a certificate from LocalMachine\My to the SQL Server instance for encrypted connections.
.PARAMETER InstanceName
  SQL Server instance name (default: MSSQLSERVER).
.PARAMETER Thumbprint
  Certificate thumbprint in LocalMachine\My to bind.
.PARAMETER ForceEncryption
  Set to $true to enforce encryption (default: $true).
#>
param(
  [string]$InstanceName = "MSSQLSERVER",
  [Parameter(Mandatory)][string]$Thumbprint,
  [bool]$ForceEncryption = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Determine instance registry key
$instanceId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").$InstanceName
if (-not $instanceId) { throw "SQL instance $InstanceName not found" }
$netlibKey = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceId\MSSQLServer\SuperSocketNetLib"

# Write thumbprint (no spaces) and ForceEncryption
$tp = ($Thumbprint -replace '\s','').ToUpper()
New-ItemProperty -Path $netlibKey -Name "Certificate" -PropertyType String -Value $tp -Force | Out-Null
New-ItemProperty -Path $netlibKey -Name "ForceEncryption" -PropertyType DWord -Value ([int]$ForceEncryption) -Force | Out-Null

# Restart SQL service
$svcName = if ($InstanceName -eq "MSSQLSERVER") { "MSSQLSERVER" } else { "MSSQL$${InstanceName}" }
Restart-Service -Name $svcName -Force -ErrorAction Stop

Write-Host "SQL Server instance $InstanceName bound to certificate $tp. ForceEncryption=$ForceEncryption"
