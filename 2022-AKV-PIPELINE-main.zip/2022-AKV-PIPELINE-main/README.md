# Molina Windows Server 2022 – SQL Dev Gold Image (Turnkey Bundle)

**Status:** HCL2 / Azure plugin – ready for Packer **v1.14.x**  
**Azure plugin:** `github.com/hashicorp/azure` **~> 2** (builder: `azure-arm`)

## What changed (critical fixes)
- Migrated from **classic JSON** (`builders`/`provisioners`) to **HCL2** layout: `source` + `build`.
- Cleaned up auth: supports **Service Principal** (secret/cert/JWT) or **Managed Identity**. No `azure_cli` knob.
- Added **Authenticode + SHA256** verification script (`scripts/verify-integrity.ps1`).
- Added **ADO pipeline** (`azure-pipelines.yml`) using `packer init/validate/build` on Windows runners.
- Pre-staging of agent installers supported; **no enrollment** at build time.
- AKV integration is **attach-at-provisioning** (do not bake secrets or the extension into the image).

## Files
- `windows-2022-sqldev.pkr.hcl` – Primary HCL2 template (Azure Managed Image output)
- `windows-2022-sqldev.pkr.json` – Equivalent HCL2/JSON (if you prefer .pkr.json)
- `example.auto.pkrvars.hcl` – Sample variables file
- `azure-pipelines.yml` – Reference Azure DevOps pipeline
- `scripts/` – Script stubs (replace with your org logic)
  - `install-prereqs.ps1`
  - `hardening-apply.ps1`
  - `install-sql.ps1`
  - `verify-integrity.ps1`

## Quick start
```powershell
# Instructions
cp example.auto.pkrvars.hcl auto.pkrvars.hcl (EDIT FILE)
packer init .
packer validate -var-file=auto.pkrvars.hcl windows-2022-sqldev.pkr.hcl
packer build -var-file=auto.pkrvars.hcl windows-2022-sqldev.pkr.hcl

Client Id and Secret are uncommented
in auto.pkrvars.hcl file

COMMENT OUT in windows-2022-sqldev.pkr.hcl
#client_cert_path = var.client_cert_path
#client_jwt       = var.client_jwt

```

# On build agent (Windows)
packer init .
packer fmt -check .
packer validate -var-file=example.auto.pkrvars.hcl windows-2022-sqldev.pkr.hcl
packer build    -var-file=example.auto.pkrvars.hcl windows-2022-sqldev.pkr.hcl
```

> Output: Managed Image named `molina-win2022-sqldev-<image_version>` in resource group `image_rg`.

## Auth options
- **Managed Identity (recommended on Azure-hosted agents)**: leave SP vars empty.
- **Service Principal**: set `client_id` and `client_secret` (or `client_cert_path`/`client_jwt`).

## Integrity verification (defense-in-depth)
- Keep using **short-lived SAS tokens** to fetch artifacts.
- After download, run `scripts/verify-integrity.ps1 -Path C:\Path\to\installer.msi -Sha256File checksums.txt`.
- Publish verification logs as evidence with the Packer **manifest**.

## Notes
- Do **not** bake Key Vault secrets/certs or the AKV extension into the image. Attach the extension at provisioning time.
- If you need Azure Compute Gallery publication, we can provide an alternate template with `shared_image_gallery_destination`.


## Azure DevOps Pipeline — Packer Install Included
Pipelines are provided under `pipelines/azure-devops/` and **install Packer automatically**:
- `win2022-image-create-windows.yml` (Windows agent) — default builds `packer/win2022-azure-base.pkr.hcl`.
- `win2022-image-create-linux.yml` (Ubuntu agent) — same as above for Linux agents.

Set these variables in your pipeline:
`AZ_SUBSCRIPTION_ID`, `AZ_TENANT_ID`, (`AZ_CLIENT_ID`/`AZ_CLIENT_SECRET` if using SP), `AZ_LOCATION`, `AZ_RG_BUILD`, `AZ_RG_IMAGES`, `IMAGE_VERSION`.

Helper scripts:
- `scripts/pipeline/install_packer_windows.ps1`
- `scripts/pipeline/install_packer_linux.sh`

> Note: `packer/base-image.pkr.hcl` uses a local Hyper‑V builder placeholder. Use the **Azure** HCL (`win2022-azure-base.pkr.hcl`) in hosted pipelines.
