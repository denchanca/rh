<#
.SYNOPSIS
 This script allows the automated installation of SQL Server 2019 and 2022 for a default instance using the default port (1433).
 It configures the instance based on the host's resources and uses custom configuration scripts.
 This was created to help speed up SQL Server builds while respecting production environment standards.

.DESCRIPTION
 Prerequisites:
 1. The script needs to be in the same folder as the SQL Server installation kit (same directory as setup.exe).
 2. The configuration files need to be in the same directory as the script and should respect the naming convention:
    - for default instance - 2022_DefaultInstTemplate.ini or 2019_DefaultInstTemplate.ini
 3. The script should be executed from PowerShell opened as admin.
 4. The script has been designed to work and tested with the provided configuration files.

 Behavior:
 This script does the following:
 - Installs SQL Server 2019 or 2022 as a default instance on the default port (1433).
 - Writes the configuration file used to C:\Temp.
 - Sets the sa password to the one provided.
 - Adds the user executing this script as a member of the sysadmin fixed server role.
 - Configures MAXDOP based on the number of cores on the machine (up to 8).
 - Configures model database file sizes and growth increments.
 - Sets the model database to use the simple recovery model.
 - Sets CTP to 50.
 - Runs any custom configuration .sql script file provided via the -CustomScript parameter.

.PARAMETER saPwd
 Mandatory. The password that will be set for the sa account during installation.

.PARAMETER InstanceRootDir
 Optional. The parent directory where the instance's main directory will be created. Defaults to C:\MSSQL if not provided.

.PARAMETER CustomScript
 Optional. Used to provide the path to a custom .sql script that does some extra post-install configuration.

.EXAMPLE
 PS>.\InstallSQLServer.ps1 -saPwd SuperStr0ngPassword
 Installs a default SQL Server instance with the sa password set as SuperStr0ngPassword on port 1433

.EXAMPLE
 PS>.\InstallSQLServer.ps1 -saPwd SuperStr0ngPassword -CustomScript "C:\Scripts\CustomConfig.sql"
 Installs a default SQL Server instance with the sa password set as SuperStr0ngPassword on port 1433 and runs the specified custom script
#>
[cmdletbinding()]
param(
	[Parameter(Mandatory = $True)]
	[string]$saPwd,
	[Parameter(Mandatory = $False)]
	[string]$InstanceRootDir = "C:\MSSQL",
	[Parameter(Mandatory = $False)]
	[string]$CustomScript
)

#Get script path
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition

##Handling Input
# If trailing backslash, remove it so it doesn't mess with the paths in the config file
if ($InstanceRootDir -like "*\") {
	$InstanceRootDir = $InstanceRootDir -replace ".{1}$"
}

# Set to default instance
$InstanceName = "MSSQLSERVER"

# Set default collation
$InstanceCollation = "SQL_Latin1_General_CP1_CI_AS"

##Handling internal variables
#Getting the version based on the config file name
$ConfigTemplateName = Get-ChildItem -Path $ScriptPath -Name *_DefaultInstTemplate.ini
$Version = $ConfigTemplateName -replace "_DefaultInstTemplate.ini", ""

#Determine build version
if ($Version -eq "2022") {
	$MajorVersion = "16"
} elseif ($Version -eq "2019") {
	$MajorVersion = "15"
} elseif ($Version -eq "2017") {
	$MajorVersion = "14"
}

#Set SQLCMD instance name
$CmdInstance = "localhost"

$HostName = [System.Net.Dns]::GetHostName()

$TempDir = "C:\Temp"
$InstallConfigFile = $TempDir + "\" + $InstanceName + "_Config.ini"
$InstancePath = $InstanceRootDir + "\" + $InstanceName
$InstanceOldPath = $InstancePath + "_old"

#Load config file template into memory
[string]$ConfigTemplate = [System.IO.File]::ReadAllText("$ScriptPath\$ConfigTemplateName")

#Check if there's already an instance with that name and cancel if yes
$ServiceName = Get-Service -Name "SQL Server ($InstanceName)" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName
if ($ServiceName -eq "SQL Server ($InstanceName)") {
	Write-Host " An instance named $InstanceName is already installed on this machine!" -Fore Red
	Write-Host " ->Canceling installation."
	Read-Host -Prompt "Press Enter to end script execution."
	exit
}

#Check if there's a leftover directory from a previous instance with the same name
if (Test-Path $InstancePath) {
	try {
		Write-Host " Found leftover instance directory from a previous installation." -fore Yellow
		Write-Host " ->Attempting to rename it..."
		Rename-Item -Path $InstancePath -NewName $InstanceOldPath -ErrorAction Stop
		Write-Host " ->Old instance directory renamed to $InstanceOldPath."
	} catch {
		#Might fail if not running from elevated PS, so trying elevated PS too
		try {
			Start-Process -NoNewWindow -Wait -FilePath "powershell" -Verb RunAs -ArgumentList "-command Rename-Item -Path $InstancePath -NewName $InstanceOldPath" -ErrorAction Stop
			Write-Host " ->Old instance directory renamed to $InstanceOldPath."
		} catch {
			Write-Host " ->Failed to rename the directory" -fore Red
			Read-Host -Prompt "Press Enter to end script execution."
			exit
		}
	}
}

#Get current user's Windows/AD account
$WinSysadminAccount = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
if (([string]::IsNullOrEmpty($WinSysadminAccount)) -or ($WinSysadminAccount -eq "The command completed successfully." )) {
	# Use admin account as a fallback in case user account can't be retrieved
	$HasWinSysadminAccount = "N"
	$WinSysadminAccount = "Administrator"
} else {
	$HasWinSysadminAccount = "Y"
}

#Create temp directory if it doesn't exist
if (!(Test-Path C:\Temp)) {
	New-Item -ItemType Directory -Force -Path C:\Temp | Out-Null
}

#Get physical core count
try {
	[int]$CoreCount = ( (Get-CimInstance -ClassName Win32_Processor).NumberOfCores | Measure-Object -Sum).Sum
} catch {
	Write-Host " Cannot determine number of CPU cores, defaulting to 4." -fore Yellow
	[int]$CoreCount = 4
}
#Don't end up with MAXDOP and tempdb data files count higher than 8
if ($CoreCount -gt 8) {
	$CoreCount = 8
}

#Prepare config file
[string]$ConfigFile = $ConfigTemplate -replace "PSReplaceInstanceName", $InstanceName
[string]$ConfigFile = $ConfigFile -replace "PSReplaceCollation", $InstanceCollation
[string]$ConfigFile = $ConfigFile -replace "PSReplaceInstRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceBkpRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceUserDataRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceUserTLogRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceTempdbDataRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceTempdbTLogRootDir", $InstanceRootDir
[string]$ConfigFile = $ConfigFile -replace "PSReplaceCoreCount", $CoreCount

$ConfigFile | Out-File -Encoding ASCII -FilePath $InstallConfigFile -Force

Write-Host " Starting SQL Server installation for instance $InstanceName..."
Write-Host " ->Note: if nothing happens, you might have a pending reboot. Restart the machine and try again." -fore Yellow
Start-Process -NoNewWindow -Wait -FilePath "$ScriptPath\Setup.exe" -ArgumentList "/SAPWD=$saPwd /Q /Action=install /IACCEPTSQLSERVERLICENSETERMS /SQLSYSADMINACCOUNTS=$WinSysadminAccount /ConfigurationFile=$InstallConfigFile"
#Check if install finished and service is running
$ServiceName = Get-Service -Name "SQL Server ($InstanceName)" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" } | Select-Object -ExpandProperty DisplayName
if ($null -eq $ServiceName) {
	while ($null -eq $ServiceName) {
		Start-Sleep -Seconds 35
		$ServiceName = Get-Service -Name "SQL Server ($InstanceName)" -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq "Running" } | Select-Object -ExpandProperty DisplayName
	}
}
#Wait 5 seconds for the system databases to be initialized
Start-Sleep -Seconds 5
Write-Host " Instance installation finished." -Fore Green
Write-Host " Proceeding with post-install configuration steps..."

#SQL Server CTP and model db tweaks
$InstanceConfigTweaks = @"
EXEC sys.sp_configure N'show advanced options', N'1';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'cost threshold for parallelism', N'50';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'backup compression default', N'1';
GO
RECONFIGURE WITH OVERRIDE;
GO
EXEC sys.sp_configure N'show advanced options', N'0';
GO
RECONFIGURE WITH OVERRIDE;
GO
ALTER DATABASE [model] SET RECOVERY SIMPLE WITH NO_WAIT;
GO
ALTER DATABASE [model] MODIFY FILE (NAME = N'modeldev', FILEGROWTH = 400MB);
GO
ALTER DATABASE [model] MODIFY FILE (NAME = N'modellog', FILEGROWTH = 300MB);
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'BUILTIN\Administrators')
BEGIN
    CREATE LOGIN [BUILTIN\Administrators] FROM WINDOWS;
    EXEC sys.sp_addsrvrolemember @loginame = N'BUILTIN\Administrators', @rolename = N'sysadmin';
END
GO
"@

#If local Admin account was added as a workaround for the install error, drop it here
if ($HasWinSysadminAccount -eq "N") {
	$InstanceConfigTweaks = $InstanceConfigTweaks + @"
DECLARE @SQL NVARCHAR(300);
DECLARE @WinSysAdminLogin NVARCHAR(128);
SELECT @WinSysAdminLogin = [name] FROM sys.server_principals
WHERE [name] LIKE N'%Administrator';
SET @SQL = N'DROP LOGIN ['+ @WinSysAdminLogin +N'];'
EXEC(@SQL);
GO
"@
}

#Refresh path environment variable so we can use sqlcmd
$Env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine")

$TestQuery = "SET NOCOUNT ON;`nSELECT 'XYZ';`nGO"
#Waiting for the instance to get out of single user mode
[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $TestQuery -x 2>&1 | Out-String
#cleanup output noise
$sqlcmdOut = $sqlcmdOut -replace " ", ""
$sqlcmdOut = $sqlcmdOut -replace "-", ""
$sqlcmdOut = $sqlcmdOut -replace "`r`n", ""
while ($sqlcmdOut -ne "XYZ") {
	Write-Host " The instance is not connectable yet - waiting 20 seconds..."
	Start-Sleep -Seconds 20
	[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $TestQuery -x 2>&1 | Out-String
	$sqlcmdOut = $sqlcmdOut -replace " ", ""
	$sqlcmdOut = $sqlcmdOut -replace "-", ""
	$sqlcmdOut = $sqlcmdOut -replace "`r`n", ""
}

[string]$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -Q $InstanceConfigTweaks -x 2>&1 | Out-String
#Cleaning up the output
$sqlcmdOut = $sqlcmdOut -replace ". Run the RECONFIGURE statement to install" , ""
Write-Host $sqlcmdOut

if (!([string]::IsNullOrEmpty($CustomScript))) {
	Write-Host " Running custom script..."
	$sqlcmdOut = sqlcmd -S $CmdInstance -U sa -P $saPwd -i "$CustomScript" -x 2>&1 | Out-String
	Write-Host $sqlcmdOut
}

Write-Host ("=" * 90)
Write-Host " SQL Server $Version installation and configuration - " -NoNewline
Write-Host "Done" -Fore Green
Write-Host " Instance: " -NoNewline
Write-Host "$HostName"
Write-Host " Instance directory: "
Write-Host "  $InstancePath"
Write-Host " Collation: $InstanceCollation"
Write-Host " sa password: $saPwd"
Write-Host " TCP port: 1433"
Write-Host " The local Administrators group has been added as a sysadmin on the instance."
Write-Host " The config .ini file used for the installation has been saved as:"
Write-Host " $InstallConfigFile"
Write-Host " "
Write-Host ("=" * 90)
Write-Host "The machine needs to be restarted to complete the installation."